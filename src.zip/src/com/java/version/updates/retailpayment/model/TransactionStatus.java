package com.java.version.updates.retailpayment.model;

// Life cycle: PENDING -> SUCCESS or FAILED, and SUCCESS -> REFUNDED. No other moves are allowed.
public enum TransactionStatus {
    PENDING,
    SUCCESS,
    FAILED,
    REFUNDED
}
