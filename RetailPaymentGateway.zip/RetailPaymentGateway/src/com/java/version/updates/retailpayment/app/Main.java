package com.java.version.updates.retailpayment.app;

import com.java.version.updates.retailpayment.exception.GatewayException;
import com.java.version.updates.retailpayment.model.Customer;
import com.java.version.updates.retailpayment.model.Order;
import com.java.version.updates.retailpayment.model.PaymentResult;
import com.java.version.updates.retailpayment.model.Transaction;
import com.java.version.updates.retailpayment.payment.CardPayment;
import com.java.version.updates.retailpayment.payment.PaymentMethod;
import com.java.version.updates.retailpayment.payment.UpiPayment;
import com.java.version.updates.retailpayment.payment.WalletPayment;
import com.java.version.updates.retailpayment.repository.TransactionRepository;
import com.java.version.updates.retailpayment.service.PaymentGatewayService;
import com.java.version.updates.retailpayment.util.ReceiptGenerator;
import com.java.version.updates.retailpayment.util.TransactionStatus;

import java.math.BigDecimal;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static final Scanner SC = new Scanner(System.in);
    private static final PaymentGatewayService SERVICE =
            new PaymentGatewayService(new TransactionRepository("data/transactions.csv"));

    public static void main(String[] args) {
        SERVICE.loadTransactions();
        System.out.println("Loaded " + SERVICE.getAllTransactions().size() + " saved transaction(s).");

        boolean running = true;
        while (running) {
            printMenu();
            int choice = readInt("Enter choice: ");
            try {
                switch (choice) {
                    case 1: registerCustomer(); break;
                    case 2: createOrder(); break;
                    case 3: makePayment(); break;
                    case 4: viewTransaction(); break;
                    case 5: viewCustomerHistory(); break;
                    case 6: refundPayment(); break;
                    case 7: SERVICE.printReport(); break;
                    case 8:
                        SERVICE.saveTransactions();
                        running = false;
                        System.out.println("Transactions saved. Goodbye!");
                        break;
                    default: System.out.println("Choose a number from 1 to 8.");
                }
            } catch (GatewayException | IllegalArgumentException ex) {
                System.out.println("Error: " + ex.getMessage());
            } catch (Exception ex) {
                System.out.println("Unexpected error: " + ex.getMessage());
            }
            System.out.println();
        }
    }

    private static void printMenu() {
        System.out.println("===== RETAIL PAYMENT GATEWAY =====");
        System.out.println("1. Register Customer");
        System.out.println("2. Create Order");
        System.out.println("3. Make Payment");
        System.out.println("4. View Transaction");
        System.out.println("5. View Customer Payment History");
        System.out.println("6. Refund Payment");
        System.out.println("7. Generate Payment Report");
        System.out.println("8. Exit");
    }

    private static void registerCustomer() throws GatewayException {
        String id = readLine("Customer ID: ");
        String name = readLine("Customer name: ");
        SERVICE.registerCustomer(new Customer(id, name));
        System.out.println("Registered customer " + id);
    }

    private static void createOrder() throws GatewayException {
        String customerId = readLine("Customer ID: ");
        String orderId = readLine("Order ID: ");
        BigDecimal amount = readMoney("Payable amount: ");
        SERVICE.createOrder(new Order(orderId, customerId, amount));
        System.out.println("Created order " + orderId);
    }

    private static void makePayment() throws GatewayException {
        String orderId = readLine("Order ID: ");
        System.out.println("Payment method: 1. UPI  2. Card simulation  3. Wallet");
        int method = readInt("Choose method: ");
        PaymentMethod paymentMethod;
        if (method == 1) {
            paymentMethod = new UpiPayment(readLine("Fake UPI ID (example demo.user@upi): "));
        } else if (method == 2) {
            paymentMethod = new CardPayment(readLine("Fake card alias (example CARD-DEMO-1234): "));
        } else if (method == 3) {
            paymentMethod = new WalletPayment(readLine("Fake wallet ID (example demo-wallet): "));
        } else {
            throw new IllegalArgumentException("Unknown payment method.");
        }

        Transaction txn = SERVICE.makePayment(orderId, paymentMethod);
        ReceiptGenerator.printReceipt(txn);
    }

    private static void viewTransaction() throws GatewayException {
        String id = readLine("Transaction ID: ");
        Transaction txn = SERVICE.getTransaction(id);
        System.out.println(txn);
    }

    private static void viewCustomerHistory() {
        String customerId = readLine("Customer ID: ");
        List<Transaction> history = SERVICE.getCustomerHistory(customerId);
        if (history.isEmpty()) {
            System.out.println("No transactions found for customer " + customerId);
            return;
        }
        history.forEach(System.out::println);
    }

    private static void refundPayment() throws GatewayException {
        String id = readLine("Transaction ID to refund: ");
        Transaction txn = SERVICE.refund(id);
        System.out.println("Refund completed.");
        ReceiptGenerator.printReceipt(txn);
    }

    private static String readLine(String prompt) {
        System.out.print(prompt);
        return SC.nextLine().trim();
    }

    private static int readInt(String prompt) {
        while (true) {
            try {
                return Integer.parseInt(readLine(prompt));
            } catch (NumberFormatException ex) {
                System.out.println("Enter a valid whole number.");
            }
        }
    }

    private static BigDecimal readMoney(String prompt) {
        while (true) {
            try {
                return new BigDecimal(readLine(prompt));
            } catch (NumberFormatException ex) {
                System.out.println("Enter a valid amount, e.g. 2500.00.");
            }
        }
    }
}
