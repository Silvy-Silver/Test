# Retail Payment Gateway — Core Java Mini Project

A console-based, **simulated** retail payment gateway built with Java 8. It does not connect to banks or payment providers and must not be used to enter real card numbers, CVVs, UPI PINs, or banking credentials.

## Concepts covered
- Classes, objects, constructors, `this`, encapsulation
- Abstract classes, interfaces, inheritance, overriding, polymorphism
- `ArrayList`, `HashMap`, generics
- Enums, `static`, `final`, exceptions
- `BigDecimal` for money
- Java 8 lambdas and Streams
- `LocalDateTime`
- CSV file I/O and transaction history reload

## IntelliJ IDEA setup
1. Extract the ZIP.
2. In IntelliJ, choose **Open** and select the extracted `RetailPaymentGateway` folder.
3. Ensure a JDK 8 or newer is configured.
4. Mark `src` as **Sources Root** if IntelliJ does not do so automatically.
5. Run `com.java.version.updates.retailpayment.app.Main`.

No Maven or external libraries are required.

## Demo payment details
Use fake values only:
- UPI: `demo.user@upi`
- Card simulation alias: `CARD-DEMO-1234` (not a real card number)
- Wallet: `demo-wallet`

To simulate a provider decline, use the fake payment alias/ID `decline-demo` where the payment method allows it. The app represents outcomes explicitly as `SUCCESS` or `FAILED`.

## Persistence
Transactions are written to `data/transactions.csv` when payments/refunds occur. The app attempts to load this file on startup. The file is created relative to the working directory, usually the project root in IntelliJ.

CSV is intentionally simple for this learning project. Do not put secrets or real payment details in it.

## Fee rule
The illustrative gateway fee is 1% of the order amount. The fee is rounded to 2 decimal places using `HALF_UP`; net amount = amount - fee. This is an assignment rule, not a real provider rate.

## Design notes
- A new transaction ID is generated for every payment attempt, including failed attempts.
- Only successful transactions can be refunded, and each transaction can be refunded once.
- Refunds are full refunds in this exercise.
- Payment details are demo identifiers only; no sensitive payment credentials are collected.
- The order/customer registries are in memory for this mini-project. The transaction history persists across restarts.
