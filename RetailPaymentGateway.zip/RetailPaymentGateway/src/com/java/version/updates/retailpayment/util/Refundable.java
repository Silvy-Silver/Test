package com.java.version.updates.retailpayment.util;

import com.java.version.updates.retailpayment.exception.GatewayException;
import com.java.version.updates.retailpayment.model.Transaction;

public interface Refundable {
    Transaction refund(String transactionId) throws GatewayException;
}
