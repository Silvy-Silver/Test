package com.java.version.updates.retailpayment.util;

import com.java.version.updates.retailpayment.model.Transaction;

public interface ReceiptGenerator {
    static void printReceipt(Transaction txn) {
        System.out.println("========== PAYMENT RECEIPT ==========");
        System.out.println("Order ID       : " + txn.getOrderId());
        System.out.println("Transaction ID : " + txn.getTransactionId());
        System.out.println("Amount         : Rs. " + txn.getAmount().toPlainString());
        System.out.println("Payment Method : " + txn.getPaymentType());
        System.out.println("Status         : " + txn.getStatus());
        System.out.println("Gateway Fee    : Rs. " + txn.getGatewayFee().toPlainString());
        System.out.println("Merchant Net   : Rs. " + txn.getNetAmount().toPlainString());
        System.out.println("Message        : " + txn.getMessage());
        System.out.println("=====================================");
    }
}
