package com.gateway.service;

import com.gateway.model.MoneyUtil;
import com.gateway.model.Transaction;
import com.gateway.model.TransactionStatus;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

// Builds the payment report using streams (filter, group, sum). It only calculates; ConsoleApp prints.
public class ReportService {

    // Immutable snapshot of payment totals. Printing is the menu's job, not the service's.
    public static final class PaymentReport {

        private final int totalAttempts;
        private final Map<TransactionStatus, Long> countByStatus;
        private final BigDecimal successfulGross;
        private final BigDecimal successfulFees;
        private final BigDecimal successfulNet;
        private final BigDecimal refundedTotal;

        private PaymentReport(int totalAttempts, Map<TransactionStatus, Long> countByStatus,
                              BigDecimal successfulGross, BigDecimal successfulFees,
                              BigDecimal successfulNet, BigDecimal refundedTotal) {
            this.totalAttempts = totalAttempts;
            this.countByStatus = Collections.unmodifiableMap(new EnumMap<TransactionStatus, Long>(countByStatus));
            this.successfulGross = successfulGross;
            this.successfulFees = successfulFees;
            this.successfulNet = successfulNet;
            this.refundedTotal = refundedTotal;
        }

        public int getTotalAttempts() {
            return totalAttempts;
        }

        public long getCount(TransactionStatus status) {
            return countByStatus.get(status);
        }

        public BigDecimal getSuccessfulGross() {
            return successfulGross;
        }

        public BigDecimal getSuccessfulFees() {
            return successfulFees;
        }

        public BigDecimal getSuccessfulNet() {
            return successfulNet;
        }

        public BigDecimal getRefundedTotal() {
            return refundedTotal;
        }
    }

    private final TransactionRepository repository;

    public ReportService(TransactionRepository repository) {
        this.repository = repository;
    }

    // Every status is pre-filled with 0 so the report always shows all four lines.
    public PaymentReport generate() {
        List<Transaction> all = repository.findAll();

        Map<TransactionStatus, Long> counts = new EnumMap<TransactionStatus, Long>(TransactionStatus.class);
        for (TransactionStatus status : TransactionStatus.values()) {
            counts.put(status, 0L); // statuses with no transactions still appear as 0
        }
        counts.putAll(all.stream().collect(Collectors.groupingBy(Transaction::getStatus, Collectors.counting())));

        List<Transaction> successful = withStatus(all, TransactionStatus.SUCCESS);
        List<Transaction> refunded = withStatus(all, TransactionStatus.REFUNDED);

        return new PaymentReport(
                all.size(),
                counts,
                sum(successful, Transaction::getAmount),
                sum(successful, Transaction::getGatewayFee),
                sum(successful, Transaction::getNetAmount),
                sum(refunded, Transaction::getAmount));
    }

    private static List<Transaction> withStatus(List<Transaction> transactions, TransactionStatus status) {
        return transactions.stream()
                .filter(t -> t.getStatus() == status)
                .collect(Collectors.toList());
    }

    private static BigDecimal sum(List<Transaction> transactions, Function<Transaction, BigDecimal> field) {
        return MoneyUtil.scale(transactions.stream().map(field).reduce(BigDecimal.ZERO, BigDecimal::add));
    }
}
