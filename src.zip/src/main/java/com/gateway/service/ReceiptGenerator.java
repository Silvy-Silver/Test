package com.gateway.service;

import com.gateway.model.Transaction;

/** Turns a transaction into printable text. Other formats (HTML, PDF) can be added by implementing this. */
public interface ReceiptGenerator {

    String generate(Transaction transaction);
}
