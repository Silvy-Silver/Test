package com.ecommerce.assignment19;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Objects;

public class CustomerOrder {
    public enum Status { COMPLETED, CANCELLED, PENDING }

    private final String orderId;
    private final String customerName;
    private final LocalDate orderDate;
    private final BigDecimal total;
    private final Status status;

    public CustomerOrder(String orderId, String customerName, LocalDate orderDate,
                         BigDecimal total, Status status) {
        this.orderId = Objects.requireNonNull(orderId);
        this.customerName = Objects.requireNonNull(customerName);
        this.orderDate = Objects.requireNonNull(orderDate);
        this.total = Objects.requireNonNull(total);
        this.status = Objects.requireNonNull(status);
    }

    public String getOrderId() { return orderId; }
    public String getCustomerName() { return customerName; }
    public LocalDate getOrderDate() { return orderDate; }
    public BigDecimal getTotal() { return total; }
    public Status getStatus() { return status; }
}
