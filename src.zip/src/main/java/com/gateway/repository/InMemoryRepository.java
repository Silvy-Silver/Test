package com.gateway.repository;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;

/** HashMap-backed lookup that also remembers insertion order (LinkedHashMap) for history views. */
public class InMemoryRepository<T, ID> implements Repository<T, ID> {

    private final Map<ID, T> items = new LinkedHashMap<ID, T>();
    private final Function<T, ID> idExtractor;

    public InMemoryRepository(Function<T, ID> idExtractor) {
        this.idExtractor = idExtractor;
    }

    @Override
    public void save(T item) {
        items.put(idExtractor.apply(item), item);
    }

    @Override
    public Optional<T> findById(ID id) {
        return Optional.ofNullable(items.get(id));
    }

    @Override
    public List<T> findAll() {
        return new ArrayList<T>(items.values());
    }
}
