package com.ecommerce.assignment19;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;

import static com.ecommerce.assignment19.CustomerOrder.Status.CANCELLED;
import static com.ecommerce.assignment19.CustomerOrder.Status.COMPLETED;
import static com.ecommerce.assignment19.CustomerOrder.Status.PENDING;

public class CustomerOrderHistory {
    public static void main(String[] args) {
        List<CustomerOrder> orders = List.of(
            new CustomerOrder("ORD-201", "Asha", LocalDate.of(2026, 1, 12), new BigDecimal("2499.00"), COMPLETED),
            new CustomerOrder("ORD-202", "Asha", LocalDate.of(2026, 2, 4), new BigDecimal("799.00"), CANCELLED),
            new CustomerOrder("ORD-203", "Asha", LocalDate.of(2026, 3, 15), new BigDecimal("5999.00"), COMPLETED),
            new CustomerOrder("ORD-204", "Ravi", LocalDate.of(2026, 3, 20), new BigDecimal("1200.00"), COMPLETED),
            new CustomerOrder("ORD-205", "Asha", LocalDate.of(2026, 4, 8), new BigDecimal("1499.00"), PENDING),
            new CustomerOrder("ORD-206", "Asha", LocalDate.of(2026, 5, 1), new BigDecimal("3200.00"), COMPLETED),
            new CustomerOrder("ORD-207", "Asha", LocalDate.of(2026, 5, 20), new BigDecimal("450.00"), CANCELLED),
            new CustomerOrder("ORD-208", "Asha", LocalDate.of(2026, 6, 2), new BigDecimal("899.00"), COMPLETED)
        );

        String customer = "Asha";
        List<CustomerOrder> history = orders.stream()
            .filter(o -> o.getCustomerName().equalsIgnoreCase(customer))
            .sorted(Comparator.comparing(CustomerOrder::getOrderDate).reversed())
            .toList();

        System.out.println("Order history for " + customer + " (newest first):");
        history.forEach(o -> System.out.printf("%s | %s | %s | ₹%s | %s%n",
            o.getOrderId(), o.getOrderDate(), o.getCustomerName(), o.getTotal(), o.getStatus()));

        System.out.println("\nLatest 5 orders:");
        history.stream()
            .limit(5)
            .forEach(o -> System.out.println(o.getOrderId() + " - " + o.getOrderDate()));

        BigDecimal completedTotal = history.stream()
            .filter(o -> o.getStatus() == COMPLETED)
            .map(CustomerOrder::getTotal)
            .reduce(BigDecimal.ZERO, BigDecimal::add);
        System.out.println("\nTotal value of completed orders: ₹" + completedTotal);

        long cancelledCount = history.stream()
            .filter(o -> o.getStatus() == CANCELLED)
            .count();
        System.out.println("Cancelled order count: " + cancelledCount);
    }
}
