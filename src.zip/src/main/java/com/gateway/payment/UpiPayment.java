package com.gateway.payment;

import com.gateway.model.PaymentType;

import java.math.BigDecimal;
import java.util.regex.Pattern;

public class UpiPayment extends PaymentMethod {

    private static final Pattern VIRTUAL_PAYMENT_ADDRESS = Pattern.compile("^[A-Za-z0-9._-]{2,}@[A-Za-z]{2,}$");

    public UpiPayment(String virtualUpiId) {
        super(PaymentType.UPI, virtualUpiId, VIRTUAL_PAYMENT_ADDRESS);
    }

    @Override
    public PaymentResult processPayment(BigDecimal amount) {
        return simulateProvider();
    }
}
