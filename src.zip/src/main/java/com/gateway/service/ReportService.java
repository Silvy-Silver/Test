package com.gateway.service;

import com.gateway.model.Transaction;
import com.gateway.model.TransactionStatus;
import com.gateway.repository.TransactionRepository;
import com.gateway.util.MoneyUtil;

import java.math.BigDecimal;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class ReportService {

    private final TransactionRepository repository;

    public ReportService(TransactionRepository repository) {
        this.repository = repository;
    }

    public PaymentReport generate() {
        List<Transaction> all = repository.findAll();

        Map<TransactionStatus, Long> counts = new EnumMap<TransactionStatus, Long>(TransactionStatus.class);
        for (TransactionStatus status : TransactionStatus.values()) {
            counts.put(status, 0L); // statuses with no transactions still appear as 0
        }
        counts.putAll(all.stream().collect(Collectors.groupingBy(Transaction::getStatus, Collectors.counting())));

        List<Transaction> successful = withStatus(all, TransactionStatus.SUCCESS);
        List<Transaction> refunded = withStatus(all, TransactionStatus.REFUNDED);

        return new PaymentReport(
                all.size(),
                counts,
                sum(successful, Transaction::getAmount),
                sum(successful, Transaction::getGatewayFee),
                sum(successful, Transaction::getNetAmount),
                sum(refunded, Transaction::getAmount));
    }

    private static List<Transaction> withStatus(List<Transaction> transactions, TransactionStatus status) {
        return transactions.stream()
                .filter(t -> t.getStatus() == status)
                .collect(Collectors.toList());
    }

    private static BigDecimal sum(List<Transaction> transactions, Function<Transaction, BigDecimal> field) {
        return MoneyUtil.scale(transactions.stream().map(field).reduce(BigDecimal.ZERO, BigDecimal::add));
    }
}
