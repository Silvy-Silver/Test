package com.ecommerce;

public sealed interface PaymentResult permits PaymentSuccess,PaymentFailure {
}
