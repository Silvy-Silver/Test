package com.java.version.updates.retailpayment.model;

import java.time.LocalDateTime;

// Something that can be refunded in full.
public interface Refundable {

    boolean isRefundable();

    // Throws com.java.version.updates.retailpayment.exception.RefundException: if {@link #isRefundable()} is false
    void refund(LocalDateTime refundedAt);
}
