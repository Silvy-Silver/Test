package com.java.version.updates.retailpayment.payment;

import com.java.version.updates.retailpayment.model.PaymentResult;

import java.math.BigDecimal;

public class UpiPayment extends PaymentMethod {
    private final String virtualUpiId;

    public UpiPayment(String virtualUpiId) {
        this.virtualUpiId = virtualUpiId == null ? "" : virtualUpiId.trim();
    }

    @Override
    public boolean validatePayment(BigDecimal amount) {
        return amount != null && amount.compareTo(BigDecimal.ZERO) > 0
                && virtualUpiId.matches("[A-Za-z0-9._-]+@[A-Za-z0-9.-]+");
    }

    @Override
    public String getPaymentType() { return "UPI"; }

    @Override
    public PaymentResult processPayment(BigDecimal amount) {
        if ("decline-demo@upi".equalsIgnoreCase(virtualUpiId)) {
            return new PaymentResult(false, "Simulated UPI provider decline");
        }
        return new PaymentResult(true, "Simulated UPI payment approved");
    }
}
