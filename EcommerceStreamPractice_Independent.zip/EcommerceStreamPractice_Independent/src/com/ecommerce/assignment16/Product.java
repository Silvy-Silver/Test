package com.ecommerce.assignment16;

public class Product {
    private final String name;
    private final String category;
    private final double price;
    private final boolean inStock;

    public Product(String name, String category, double price, boolean inStock) {
        this.name = name;
        this.category = category;
        this.price = price;
        this.inStock = inStock;
    }

    public String getName() { return name; }
    public String getCategory() { return category; }
    public double getPrice() { return price; }
    public boolean isInStock() { return inStock; }

    @Override
    public String toString() {
        return String.format("%s (%s) - ₹%.2f", name, category, price);
    }
}
