package com.gateway.util;

import java.util.ArrayList;
import java.util.List;

/** Minimal CSV reader/writer (quotes, commas inside fields). One implementation shared by every repository. */
public final class CsvUtil {

    private CsvUtil() {
    }

    public static String toLine(String... fields) {
        StringBuilder line = new StringBuilder();
        for (int i = 0; i < fields.length; i++) {
            if (i > 0) {
                line.append(',');
            }
            line.append(escape(fields[i]));
        }
        return line.toString();
    }

    public static String[] parseLine(String line) {
        List<String> fields = new ArrayList<String>();
        StringBuilder current = new StringBuilder();
        boolean inQuotes = false;

        for (int i = 0; i < line.length(); i++) {
            char ch = line.charAt(i);
            if (ch == '"') {
                if (inQuotes && i + 1 < line.length() && line.charAt(i + 1) == '"') {
                    current.append('"');
                    i++;
                } else {
                    inQuotes = !inQuotes;
                }
            } else if (ch == ',' && !inQuotes) {
                fields.add(current.toString());
                current.setLength(0);
            } else {
                current.append(ch);
            }
        }
        fields.add(current.toString());
        return fields.toArray(new String[0]);
    }

    private static String escape(String value) {
        if (value == null) {
            return "";
        }
        String singleLine = value.replace('\r', ' ').replace('\n', ' ');
        if (singleLine.contains(",") || singleLine.contains("\"")) {
            return "\"" + singleLine.replace("\"", "\"\"") + "\"";
        }
        return singleLine;
    }
}
