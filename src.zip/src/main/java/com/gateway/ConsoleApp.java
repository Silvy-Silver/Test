package com.gateway;

import com.gateway.exception.GatewayException;
import com.gateway.exception.ValidationException;
import com.gateway.model.Customer;
import com.gateway.model.Order;
import com.gateway.model.OrderItem;
import com.gateway.model.PaymentType;
import com.gateway.model.Product;
import com.gateway.model.Transaction;
import com.gateway.model.TransactionStatus;
import com.gateway.payment.CardPayment;
import com.gateway.payment.PaymentMethod;
import com.gateway.payment.UpiPayment;
import com.gateway.payment.WalletPayment;
import com.gateway.service.CustomerService;
import com.gateway.service.OrderService;
import com.gateway.service.ReportService.PaymentReport;

import com.gateway.service.PaymentService;
import com.gateway.service.ReceiptGenerator;
import com.gateway.service.ReportService;
import com.gateway.model.MoneyUtil;

import java.io.InputStream;
import java.io.PrintStream;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.util.function.Function;

// Console menu. It only reads input, calls services and prints results; it contains no business rules.
// Menu entries are registered in a map, so adding an option means adding one line, not another switch case.
public class ConsoleApp {

    private static final class MenuItem {
        private final String label;
        private final Runnable action;

        private MenuItem(String label, Runnable action) {
            this.label = label;
            this.action = action;
        }
    }

    private final CustomerService customerService;
    private final OrderService orderService;
    private final PaymentService paymentService;
    private final ReportService reportService;
    private final ReceiptGenerator receiptGenerator;
    private final Scanner scanner;
    private final PrintStream out;
    // menu number -> label + action. Linked map keeps the display order.
    private final Map<Integer, MenuItem> menu = new LinkedHashMap<Integer, MenuItem>();
    private boolean running = true;

    public ConsoleApp(CustomerService customerService, OrderService orderService, PaymentService paymentService,
                      ReportService reportService, ReceiptGenerator receiptGenerator,
                      InputStream in, PrintStream out) {
        this.customerService = customerService;
        this.orderService = orderService;
        this.paymentService = paymentService;
        this.reportService = reportService;
        this.receiptGenerator = receiptGenerator;
        this.scanner = new Scanner(in);
        this.out = out;

        // To add a menu option: write a private method below and add one menu.put line here.
        menu.put(1, new MenuItem("Register Customer", this::registerCustomer));
        menu.put(2, new MenuItem("Create Order", this::createOrder));
        menu.put(3, new MenuItem("Make Payment", this::makePayment));
        menu.put(4, new MenuItem("View Transaction", this::viewTransaction));
        menu.put(5, new MenuItem("View Customer Payment History", this::viewCustomerHistory));
        menu.put(6, new MenuItem("Refund Payment", this::refundPayment));
        menu.put(7, new MenuItem("Generate Payment Report", this::printReport));
        menu.put(8, new MenuItem("Exit", this::exit));
    }

    // Main loop. Ends when the user picks Exit or the input stream closes.
    public void run() {
        try {
            while (running) {
                printMenu();
                MenuItem item = menu.get(readInt("Enter choice: "));
                if (item == null) {
                    out.println("Please choose a number from the menu.");
                    continue;
                }
                runSafely(item.action);
            }
        } catch (NoSuchElementException endOfInput) {
            out.println();
            out.println("Input closed. Goodbye!");
        }
    }

    // The one place where business errors are turned into messages for the user.
    private void runSafely(Runnable action) {
        try {
            action.run();
        } catch (GatewayException e) {
            out.println("Error: " + e.getMessage());
        } catch (NoSuchElementException e) {
            throw e; // input ended: let run() finish cleanly
        } catch (RuntimeException e) {
            out.println("Unexpected problem: " + e.getMessage());
        }
    }

    private void printMenu() {
        out.println();
        out.println("===== RETAIL PAYMENT GATEWAY =====");
        for (Map.Entry<Integer, MenuItem> entry : menu.entrySet()) {
            out.println(entry.getKey() + ". " + entry.getValue().label);
        }
    }

    // ---------- menu actions ----------

    private void registerCustomer() {
        String name = readLine("Name: ");
        String email = readLine("Email: ");
        Customer customer = customerService.register(name, email);
        out.println("Customer registered. Customer ID: " + customer.getCustomerId());
    }

    // Flow: find customer by email -> choose products and quantities -> service creates the order.
    private void createOrder() {
        Customer customer = askCustomerByEmail();
        List<Product> products = orderService.getProducts();
        printProducts(products);

        Map<String, Integer> quantities = new LinkedHashMap<String, Integer>();
        while (true) {
            int number = readInt("Choose product number (0 to finish): ");
            if (number == 0) {
                break;
            }
            if (number < 1 || number > products.size()) {
                out.println("That product number is not available.");
                continue;
            }
            Product product = products.get(number - 1);
            int quantity = readInt("Quantity for " + product.getName() + ": ");
            if (quantity <= 0) {
                out.println("Quantity must be at least 1.");
                continue;
            }
            quantities.merge(product.getProductId(), quantity, Integer::sum);
            out.println("Added " + quantity + " x " + product.getName());
            if (!yesNo("Add another product? (y/n): ")) {
                break;
            }
        }
        if (quantities.isEmpty()) {
            out.println("No products selected. No order was created.");
            return;
        }

        Order order = orderService.createOrder(customer.getCustomerId(), quantities);
        printOrder(order);
    }

    // Flow: find customer by email -> pick an unpaid order -> choose method -> enter details -> pay.
    private void makePayment() {
        Customer customer = askCustomerByEmail();
        Order order = pick("Unpaid orders", paymentService.getUnpaidOrders(customer.getCustomerId()),
                o -> o.getOrderId() + " - " + MoneyUtil.format(o.getAmount()),
                "Which order do you want to pay for?", "This customer has no unpaid orders.");
        if (order == null) {
            return;
        }
        out.println("Amount to pay: " + MoneyUtil.format(order.getAmount()));

        PaymentType type = choosePaymentType();
        String reference = readLine(type.getReferencePrompt() + ": ");
        Transaction transaction = paymentService.pay(order.getOrderId(), createPaymentMethod(type, reference));

        out.println();
        out.println(receiptGenerator.generate(transaction));
    }

    private void viewTransaction() {
        Transaction transaction = paymentService.getTransaction(readLine("Transaction ID: "));
        out.println();
        out.println(receiptGenerator.generate(transaction));
    }

    private void viewCustomerHistory() {
        Customer customer = askCustomerByEmail();
        List<Transaction> history = paymentService.getCustomerHistory(customer.getCustomerId());

        out.println();
        out.println("Payment history for " + customer.getName() + " (" + customer.getCustomerId() + ")");
        if (history.isEmpty()) {
            out.println("No payments found.");
            return;
        }
        out.printf("%-10s %-8s %-8s %14s  %-9s%n", "Txn", "Order", "Method", "Amount", "Status");
        for (Transaction t : history) {
            out.printf("%-10s %-8s %-8s %14s  %-9s%n", t.getTransactionId(), t.getOrderId(),
                    t.getPaymentType().getDisplayName(), MoneyUtil.format(t.getAmount()), t.getStatus());
        }
    }

    // Flow: find customer by email -> pick one of their successful payments -> refund.
    private void refundPayment() {
        Customer customer = askCustomerByEmail();
        Transaction chosen = pick("Refundable payments",
                paymentService.getRefundableTransactions(customer.getCustomerId()),
                t -> t.getTransactionId() + " - Order " + t.getOrderId() + " - " + MoneyUtil.format(t.getAmount()),
                "Which payment do you want to refund?", "This customer has no refundable payments.");
        if (chosen == null) {
            return;
        }
        Transaction refunded = paymentService.refund(chosen.getTransactionId());
        out.println("Refund completed.");
        out.println();
        out.println(receiptGenerator.generate(refunded));
    }

    private void printReport() {
        PaymentReport report = reportService.generate();
        out.println();
        out.println("========== PAYMENT REPORT ==========");
        out.println("Total attempts   : " + report.getTotalAttempts());
        for (TransactionStatus status : TransactionStatus.values()) {
            out.printf("%-17s: %d%n", capitalise(status), report.getCount(status));
        }
        out.println("Successful gross : " + MoneyUtil.format(report.getSuccessfulGross()));
        out.println("Gateway fees     : " + MoneyUtil.format(report.getSuccessfulFees()));
        out.println("Merchant net     : " + MoneyUtil.format(report.getSuccessfulNet()));
        out.println("Refunded total   : " + MoneyUtil.format(report.getRefundedTotal()));
        out.println("====================================");
    }

    private void exit() {
        running = false;
        out.println("Thank you. Goodbye!");
    }

    // ---------- keyboard input ----------

    // Throws NoSuchElementException: when the input has ended
    private String readLine(String prompt) {
        out.print(prompt);
        return scanner.nextLine().trim();
    }

    private int readInt(String prompt) {
        while (true) {
            try {
                return Integer.parseInt(readLine(prompt));
            } catch (NumberFormatException e) {
                out.println("Please enter a whole number.");
            }
        }
    }

    private boolean yesNo(String prompt) {
        while (true) {
            String text = readLine(prompt);
            if (text.equalsIgnoreCase("y") || text.equalsIgnoreCase("yes")) {
                return true;
            }
            if (text.equalsIgnoreCase("n") || text.equalsIgnoreCase("no")) {
                return false;
            }
            out.println("Please enter y or n.");
        }
    }

    // ---------- helpers ----------

    // Shared by every option that starts with an email lookup.
    private Customer askCustomerByEmail() {
        Customer customer = customerService.findByEmail(readLine("Customer email: "));
        out.println("Customer: " + customer.getName() + " (" + customer.getCustomerId() + ")");
        return customer;
    }

    // Shows a numbered list and returns the chosen item, or null if the list is empty or the user cancels.
    private <T> T pick(String title, List<T> items, Function<T, String> describe, String prompt, String emptyMessage) {
        if (items.isEmpty()) {
            out.println(emptyMessage);
            return null;
        }
        out.println();
        out.println(title + ":");
        for (int i = 0; i < items.size(); i++) {
            out.println("  " + (i + 1) + ". " + describe.apply(items.get(i)));
        }
        int choice = readInt(prompt + " (0 to cancel): ");
        if (choice == 0) {
            out.println("Cancelled.");
            return null;
        }
        if (choice < 1 || choice > items.size()) {
            throw new ValidationException("Please choose a number from the list.");
        }
        return items.get(choice - 1);
    }

    private PaymentType choosePaymentType() {
        PaymentType[] types = PaymentType.values();
        out.println("Payment method:");
        for (int i = 0; i < types.length; i++) {
            out.println("  " + (i + 1) + ". " + types[i].getDisplayName());
        }
        int choice = readInt("Choose method: ");
        if (choice < 1 || choice > types.length) {
            throw new ValidationException("Unknown payment method.");
        }
        return types[choice - 1];
    }

    // Maps the chosen PaymentType to its class. A new payment method needs one more case here.
    private PaymentMethod createPaymentMethod(PaymentType type, String reference) {
        switch (type) {
            case UPI:
                return new UpiPayment(reference);
            case CARD_SIMULATION:
                return new CardPayment(reference);
            default:
                return new WalletPayment(reference);
        }
    }

    private void printProducts(List<Product> products) {
        out.println();
        out.println("Available products:");
        for (int i = 0; i < products.size(); i++) {
            Product p = products.get(i);
            out.printf("  %d. %-22s %12s%n", i + 1, p.getName(), MoneyUtil.format(p.getPrice()));
        }
    }

    private void printOrder(Order order) {
        out.println();
        out.println("Order created. Order ID: " + order.getOrderId());
        for (OrderItem item : order.getItems()) {
            out.printf("  %d x %-22s %12s%n", item.getQuantity(), item.getProductName(),
                    MoneyUtil.format(item.getLineTotal()));
        }
        out.println("Total payable: " + MoneyUtil.format(order.getAmount()));
    }

    private static String capitalise(TransactionStatus status) {
        String name = status.name();
        return name.charAt(0) + name.substring(1).toLowerCase();
    }
}
