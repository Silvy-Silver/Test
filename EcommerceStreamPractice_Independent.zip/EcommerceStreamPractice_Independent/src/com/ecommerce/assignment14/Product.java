package com.ecommerce.assignment14;

public class Product {
    private final String name;

    public Product(String name) { this.name = name; }
    public String getName() { return name; }
}
