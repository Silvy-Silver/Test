package com.gateway.model;

import com.gateway.exception.ValidationException;
import com.gateway.util.MoneyUtil;
import com.gateway.util.Validation;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Order {

    private final String orderId;
    private final String customerId;
    private final List<OrderItem> items;
    private final BigDecimal amount;

    public Order(String orderId, String customerId, List<OrderItem> items) {
        this.orderId = Validation.requireNotBlank(orderId, "Order ID");
        this.customerId = Validation.requireNotBlank(customerId, "Customer ID");
        if (items == null || items.isEmpty()) {
            throw new ValidationException("An order must contain at least one product.");
        }
        this.items = Collections.unmodifiableList(new ArrayList<OrderItem>(items));
        this.amount = MoneyUtil.scale(this.items.stream()
                .map(OrderItem::getLineTotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add));
    }

    public String getOrderId() {
        return orderId;
    }

    public String getCustomerId() {
        return customerId;
    }

    public List<OrderItem> getItems() {
        return items;
    }

    /** Total payable for the whole order. */
    public BigDecimal getAmount() {
        return amount;
    }
}
