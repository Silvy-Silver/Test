package com.gateway.repository;

import com.gateway.util.CsvUtil;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import java.util.logging.Logger;

/**
 * An in-memory repository that is saved to a CSV file after every change and reloaded on start-up,
 * so data survives restarts. All file handling lives here once; a concrete repository only describes
 * how one item maps to CSV rows ({@link #toRows}) and back ({@link #fromRows}).
 * <p>
 * Subclasses must call {@link #load()} at the end of their own constructor.
 */
public abstract class CsvRepository<T, ID> extends InMemoryRepository<T, ID> {

    private static final Logger LOG = Logger.getLogger(CsvRepository.class.getName());

    private final Path file;
    private final String header;
    private final int columnCount;

    protected CsvRepository(Path file, String header, Function<T, ID> idExtractor) {
        super(idExtractor);
        this.file = file;
        this.header = header;
        this.columnCount = header.split(",").length;
    }

    /** One item becomes one or more rows (an order has one row per product line). */
    protected abstract List<String[]> toRows(T item);

    /** Rebuilds items from the saved rows. Use {@link #mapEachRow} when every row is one item. */
    protected abstract List<T> fromRows(List<String[]> rows);

    /** Converts each row with the mapper; a bad row is logged and skipped instead of crashing the program. */
    protected List<T> mapEachRow(List<String[]> rows, Function<String[], T> mapper) {
        List<T> items = new ArrayList<T>();
        for (String[] row : rows) {
            try {
                items.add(mapper.apply(row));
            } catch (RuntimeException e) {
                logSkipped(e);
            }
        }
        return items;
    }

    protected void logSkipped(RuntimeException e) {
        LOG.warning("Skipping invalid saved row in " + file.getFileName() + ": " + e.getMessage());
    }

    @Override
    public void save(T item) {
        super.save(item);
        flush();
    }

    protected void load() {
        if (!Files.exists(file)) {
            return;
        }
        List<String> lines;
        try {
            lines = Files.readAllLines(file, StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new UncheckedIOException("Could not read " + file, e);
        }
        List<String[]> rows = new ArrayList<String[]>();
        for (int i = 1; i < lines.size(); i++) { // line 0 is the header
            if (lines.get(i).trim().isEmpty()) {
                continue;
            }
            String[] row = CsvUtil.parseLine(lines.get(i));
            if (row.length == columnCount) {
                rows.add(row);
            } else {
                LOG.warning("Skipping row " + (i + 1) + " in " + file.getFileName()
                        + ": expected " + columnCount + " columns but found " + row.length);
            }
        }
        for (T item : fromRows(rows)) {
            super.save(item); // super: do not rewrite the file for every loaded item
        }
    }

    private void flush() {
        List<String> lines = new ArrayList<String>();
        lines.add(header);
        for (T item : findAll()) {
            for (String[] row : toRows(item)) {
                lines.add(CsvUtil.toLine(row));
            }
        }
        try {
            Path parent = file.toAbsolutePath().getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }
            Files.write(file, lines, StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new UncheckedIOException("Could not write " + file, e);
        }
    }
}
