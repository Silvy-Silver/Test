package com.gateway;

import com.gateway.repository.CustomerRepository;
import com.gateway.repository.OrderRepository;
import com.gateway.repository.TransactionRepository;
import com.gateway.service.CustomerService;
import com.gateway.service.OrderService;
import com.gateway.service.PaymentService;
import com.gateway.service.ProductCatalog;
import com.gateway.service.ReportService;
import com.gateway.service.TextReceiptGenerator;
import com.gateway.ui.ConsoleApp;
import com.gateway.ui.ConsoleInput;

import java.nio.file.Path;
import java.nio.file.Paths;

/** Wires the layers together and starts the menu. No business logic lives here. */
public final class Main {

    private Main() {
    }

    public static void main(String[] args) {
        Path dataDir = Paths.get(args.length > 0 ? args[0] : "data");

        CustomerRepository customerRepository = new CustomerRepository(dataDir.resolve("customers.csv"));
        OrderRepository orderRepository = new OrderRepository(dataDir.resolve("orders.csv"));
        TransactionRepository transactionRepository = new TransactionRepository(dataDir.resolve("transactions.csv"));

        CustomerService customerService = new CustomerService(customerRepository);
        OrderService orderService = new OrderService(orderRepository, customerService, new ProductCatalog());
        PaymentService paymentService = new PaymentService(transactionRepository, orderService);
        ReportService reportService = new ReportService(transactionRepository);

        new ConsoleApp(customerService, orderService, paymentService, reportService,
                new TextReceiptGenerator(), new ConsoleInput(System.in, System.out), System.out).run();
    }
}
