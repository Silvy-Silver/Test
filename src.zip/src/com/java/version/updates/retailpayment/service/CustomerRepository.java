package com.java.version.updates.retailpayment.service;

import com.java.version.updates.retailpayment.model.Customer;

import java.nio.file.Path;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

// Saves customers to customers.csv. Columns: customerId,name,email.
public final class CustomerRepository extends CsvRepository<Customer, String> {

    public CustomerRepository(Path file) {
        super(file, "customerId,name,email", Customer::getCustomerId);
        load();
    }

    // Email lookup ignores upper/lower case.
    public Optional<Customer> findByEmail(String email) {
        return findAll().stream()
                .filter(customer -> customer.getEmail().equalsIgnoreCase(email))
                .findFirst();
    }

    @Override
    protected List<String[]> toRows(Customer c) {
        return Collections.singletonList(new String[]{c.getCustomerId(), c.getName(), c.getEmail()});
    }

    @Override
    protected List<Customer> fromRows(List<String[]> rows) {
        return mapEachRow(rows, row -> new Customer(row[0], row[1], row[2]));
    }
}
