package com.java.version.updates.retailpayment.model;

// Supported payment methods. The prompt text lives here so the menu never needs an if/else per method.
public enum PaymentType {

    // The prompt text lives here so the menu never needs an if/else per payment method.
    UPI("UPI", "Simulated UPI ID (e.g. demo.user@upi)"),
    CARD_SIMULATION("Card", "Simulated card alias (e.g. CARD-DEMO1234)"),
    WALLET("Wallet", "Simulated wallet ID (e.g. WLT-DEMO01)");

    private final String displayName;
    private final String referencePrompt;

    PaymentType(String displayName, String referencePrompt) {
        this.displayName = displayName;
        this.referencePrompt = referencePrompt;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getReferencePrompt() {
        return referencePrompt;
    }
}
