package com.java.version.updates.retailpayment.service;

import com.java.version.updates.retailpayment.model.PaymentType;
import com.java.version.updates.retailpayment.model.Transaction;
import com.java.version.updates.retailpayment.model.TransactionStatus;

import java.math.BigDecimal;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

// Saves transactions to transactions.csv. The netAmount column is written for readability only.
public final class TransactionRepository extends CsvRepository<Transaction, String> {

    public TransactionRepository(Path file) {
        super(file, "transactionId,orderId,customerId,amount,gatewayFee,netAmount,paymentType,status,"
                + "createdAt,refundedAt,message", Transaction::getTransactionId);
        load();
    }

    public List<Transaction> findByOrderId(String orderId) {
        return findAll().stream()
                .filter(t -> t.getOrderId().equals(orderId))
                .collect(Collectors.toList());
    }

    public List<Transaction> findByCustomerId(String customerId) {
        return findAll().stream()
                .filter(t -> t.getCustomerId().equals(customerId))
                .collect(Collectors.toList());
    }

    @Override
    protected List<String[]> toRows(Transaction t) {
        return Collections.singletonList(new String[]{
                t.getTransactionId(),
                t.getOrderId(),
                t.getCustomerId(),
                t.getAmount().toPlainString(),
                t.getGatewayFee().toPlainString(),
                t.getNetAmount().toPlainString(),
                t.getPaymentType().name(),
                t.getStatus().name(),
                t.getCreatedAt().toString(),
                t.getRefundedAt() == null ? "" : t.getRefundedAt().toString(),
                t.getMessage()
        });
    }

    @Override
    protected List<Transaction> fromRows(List<String[]> rows) {
        // row[5] (net amount) is not read: it is always amount minus fee.
        return mapEachRow(rows, row -> Transaction.restore(
                row[0], row[1], row[2],
                new BigDecimal(row[3]),
                new BigDecimal(row[4]),
                PaymentType.valueOf(row[6]),
                LocalDateTime.parse(row[8]),
                TransactionStatus.valueOf(row[7]),
                row[9].isEmpty() ? null : LocalDateTime.parse(row[9]),
                row[10]));
    }
}
