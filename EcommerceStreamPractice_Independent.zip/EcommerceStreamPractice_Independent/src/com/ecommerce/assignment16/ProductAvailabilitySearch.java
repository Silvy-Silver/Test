package com.ecommerce.assignment16;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;

public class ProductAvailabilitySearch {
    public static void main(String[] args) {
        List<Product> products = List.of(
            new Product("Gaming Mouse", "Accessories", 1800, true),
            new Product("Office Mouse", "Accessories", 650, true),
            new Product("Webcam", "Accessories", 2400, false),
            new Product("Keyboard", "Accessories", 1300, true),
            new Product("USB Hub", "Accessories", 900, true),
            new Product("Monitor", "Displays", 14000, true)
        );

        String category = "Accessories";

        Optional<Product> first = products.stream()
            .filter(Product::isInStock)
            .filter(p -> p.getCategory().equalsIgnoreCase(category))
            .findFirst();
        System.out.println("First available in " + category + ": " +
            first.map(Product::toString).orElse("No available product found"));

        Optional<Product> cheapest = products.stream()
            .filter(Product::isInStock)
            .filter(p -> p.getCategory().equalsIgnoreCase(category))
            .min(Comparator.comparingDouble(Product::getPrice));
        System.out.println("Cheapest available: " +
            cheapest.map(Product::toString).orElse("No available product found"));

        System.out.println("Up to 5 available products, cheapest first:");
        products.stream()
            .filter(Product::isInStock)
            .filter(p -> p.getCategory().equalsIgnoreCase(category))
            .sorted(Comparator.comparingDouble(Product::getPrice))
            .limit(5)
            .forEach(System.out::println);
    }
}
