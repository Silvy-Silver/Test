package com.java.version.updates.exercise4;

public sealed interface PaymentResult permits PaymentSuccess,PaymentFailure {
}
