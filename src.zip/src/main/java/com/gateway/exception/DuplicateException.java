package com.gateway.exception;

/** The operation would create a duplicate (same email, order paid twice). */
public class DuplicateException extends GatewayException {

    private static final long serialVersionUID = 1L;

    public DuplicateException(String message) {
        super(message);
    }
}
