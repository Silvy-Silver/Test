package com.java.version.updates.retailpayment.model;
public class Customer {
    private final String customerId, name, email;
    public Customer(String customerId, String name, String email) {
        if (customerId == null || customerId.trim().isEmpty()) throw new IllegalArgumentException("Customer ID is required.");
        if (name == null || name.trim().isEmpty()) throw new IllegalArgumentException("Name is required.");
        if (email == null || !email.matches("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$"))
            throw new IllegalArgumentException("Please enter a valid email address.");
        this.customerId = customerId; this.name = name.trim(); this.email = email.trim();
    }
    public String getCustomerId() { return customerId; }
    public String getName() { return name; }
    public String getEmail() { return email; }
}
