package com.gateway.service;

import com.gateway.exception.DuplicateException;
import com.gateway.exception.NotFoundException;
import com.gateway.model.Customer;
import com.gateway.repository.CustomerRepository;
import com.gateway.util.IdGenerator;
import com.gateway.util.Validation;

import java.util.stream.Collectors;

public class CustomerService {

    private final CustomerRepository repository;

    public CustomerService(CustomerRepository repository) {
        this.repository = repository;
        IdGenerator.CUSTOMER.advancePast(
                repository.findAll().stream().map(Customer::getCustomerId).collect(Collectors.toList()));
    }

    public Customer register(String name, String email) {
        // Validate first so a rejected request never consumes an ID.
        String cleanName = Validation.requireNotBlank(name, "Name");
        String cleanEmail = Validation.requireEmail(email);
        if (repository.findByEmail(cleanEmail).isPresent()) {
            throw new DuplicateException("That email is already registered: " + cleanEmail);
        }
        Customer customer = new Customer(IdGenerator.CUSTOMER.next(), cleanName, cleanEmail);
        repository.save(customer);
        return customer;
    }

    public Customer findByEmail(String email) {
        String cleanEmail = Validation.requireNotBlank(email, "Email");
        return repository.findByEmail(cleanEmail)
                .orElseThrow(() -> new NotFoundException("Customer with email", cleanEmail));
    }

    public Customer getCustomer(String customerId) {
        return repository.findById(customerId)
                .orElseThrow(() -> new NotFoundException("Customer", customerId));
    }
}
