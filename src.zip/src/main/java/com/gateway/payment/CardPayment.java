package com.gateway.payment;

import com.gateway.model.PaymentType;

import java.math.BigDecimal;
import java.util.regex.Pattern;

// Uses a fictional card alias such as CARD-DEMO1234. Never ask for a real card number.
public class CardPayment extends PaymentMethod {

    // Valid shape: CARD- followed by 4 to 12 letters or digits.
    private static final Pattern CARD_ALIAS = Pattern.compile("^CARD-[A-Z0-9]{4,12}$", Pattern.CASE_INSENSITIVE);

    public CardPayment(String cardAlias) {
        super(PaymentType.CARD_SIMULATION, cardAlias, CARD_ALIAS);
    }

    @Override
    public PaymentResult processPayment(BigDecimal amount) {
        return simulateProvider();
    }
}
