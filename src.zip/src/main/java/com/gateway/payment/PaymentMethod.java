package com.gateway.payment;

import com.gateway.exception.ValidationException;
import com.gateway.model.PaymentType;
import com.gateway.model.Validation;

import java.math.BigDecimal;
import java.util.Locale;
import java.util.regex.Pattern;

// Common contract for all payment methods.
//
// The base class owns everything the three methods share (amount check, reference format check,
// the deterministic "decline" rule). Subclasses only say what is different about them.
//
// Simulation rule: any reference containing the word DECLINE (for example CARD-DECLINE) is declined
// by the fake provider, so tests and demos are fully deterministic.
public abstract class PaymentMethod {

    private static final String DECLINE_KEYWORD = "DECLINE";

    private final PaymentType paymentType;
    private final String reference;
    private final Pattern referencePattern;

    protected PaymentMethod(PaymentType paymentType, String reference, Pattern referencePattern) {
        this.paymentType = paymentType;
        this.reference = reference == null ? "" : reference.trim();
        this.referencePattern = referencePattern;
    }

    public PaymentType getPaymentType() {
        return paymentType;
    }

    // Checks the amount and the simulated payment details. Throws ValidationException if either is bad.
    public final void validatePayment(BigDecimal amount) {
        Validation.requirePositiveAmount(amount, "Payment amount");
        if (!referencePattern.matcher(reference).matches()) {
            throw new ValidationException("Invalid " + paymentType.getDisplayName()
                    + " details. Expected: " + paymentType.getReferencePrompt());
        }
    }

    // Asks the simulated provider to process the payment. Each method may add its own rules.
    public abstract PaymentResult processPayment(BigDecimal amount);

    // Shared fake-provider behaviour: approve unless the reference asks to be declined.
    protected PaymentResult simulateProvider() {
        if (reference.toUpperCase(Locale.ROOT).contains(DECLINE_KEYWORD)) {
            return PaymentResult.declined(paymentType.getDisplayName() + " provider declined the payment (simulated)");
        }
        return PaymentResult.approved(paymentType.getDisplayName() + " payment approved (simulated)");
    }
}
