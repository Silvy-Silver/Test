package com.java.version.updates.exercise4;

public final class PaymentSuccess implements PaymentResult {
    private final String transactionId;

    public PaymentSuccess(String transactionId) {
        this.transactionId=transactionId;
    }

    public String getTransactionId() {
        return transactionId;
    }
}
