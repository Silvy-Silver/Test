package com.java.version.updates.retailpayment.repository;

import com.java.version.updates.retailpayment.model.Transaction;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class TransactionRepository implements GenericRepository<Transaction, String> {
    private final Map<String, Transaction> byId = new HashMap<String, Transaction>();
    private final List<Transaction> history = new ArrayList<Transaction>();
    private final Path file;

    public TransactionRepository(String fileName) {
        this.file = Paths.get(fileName);
    }

    @Override
    public void save(Transaction txn) {
        if (!byId.containsKey(txn.getTransactionId())) {
            history.add(txn);
        }
        byId.put(txn.getTransactionId(), txn);
    }

    @Override
    public Optional<Transaction> findById(String id) {
        return Optional.ofNullable(byId.get(id));
    }

    @Override
    public List<Transaction> findAll() {
        return new ArrayList<Transaction>(history);
    }

    public void load() {
        if (!Files.exists(file)) {
            return;
        }
        try (BufferedReader br = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
            String line;
            boolean first = true;
            while ((line = br.readLine()) != null) {
                if (first && line.startsWith("transactionId,")) {
                    first = false;
                    continue;
                }
                first = false;
                if (line.trim().isEmpty()) {
                    continue;
                }
                try {
                    save(Transaction.fromCsv(line));
                } catch (RuntimeException ex) {
                    System.out.println("Skipping invalid saved transaction row: " + ex.getMessage());
                }
            }
        } catch (IOException ex) {
            System.out.println("Could not load transaction history: " + ex.getMessage());
        }
    }

    public void saveAll() {
        try {
            Path parent = file.getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }
            try (BufferedWriter bw = Files.newBufferedWriter(file, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING)) {
                bw.write("transactionId,orderId,customerId,amount,gatewayFee,netAmount,paymentType,status,createdAt,refundedAt,message");
                bw.newLine();
                for (Transaction txn : history) {
                    bw.write(txn.toCsv());
                    bw.newLine();
                }
            }
        } catch (IOException ex) {
            throw new IllegalStateException("Could not save transaction history to " + file + ": " + ex.getMessage(), ex);
        }
    }
}
