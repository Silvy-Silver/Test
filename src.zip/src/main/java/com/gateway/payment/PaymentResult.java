package com.gateway.payment;

/** Outcome reported by the (simulated) payment provider. */
public final class PaymentResult {

    private final boolean approved;
    private final String message;

    private PaymentResult(boolean approved, String message) {
        this.approved = approved;
        this.message = message;
    }

    public static PaymentResult approved(String message) {
        return new PaymentResult(true, message);
    }

    public static PaymentResult declined(String message) {
        return new PaymentResult(false, message);
    }

    public boolean isApproved() {
        return approved;
    }

    public String getMessage() {
        return message;
    }
}
