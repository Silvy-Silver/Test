package com.gateway.service;

import com.gateway.exception.NotFoundException;
import com.gateway.model.Product;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

// The fixed list of products the shop sells.
public class ProductCatalog {

    private final List<Product> products = new ArrayList<Product>();

    public ProductCatalog() {
        add("P101", "Wireless Mouse", "799.00");
        add("P102", "Mechanical Keyboard", "2499.00");
        add("P103", "USB-C Hub", "1599.00");
        add("P104", "Headphones", "1999.00");
        add("P105", "Laptop Stand", "1299.00");
        add("P106", "Webcam", "1799.00");
    }

    private void add(String id, String name, String price) {
        products.add(new Product(id, name, new BigDecimal(price)));
    }

    public List<Product> getProducts() {
        return Collections.unmodifiableList(products);
    }

    public Product getProduct(String productId) {
        return products.stream()
                .filter(product -> product.getProductId().equals(productId))
                .findFirst()
                .orElseThrow(() -> new NotFoundException("Product", productId));
    }
}
