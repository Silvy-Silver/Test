package com.gateway.service;

import com.gateway.exception.NotFoundException;
import com.gateway.exception.ValidationException;
import com.gateway.model.Order;
import com.gateway.model.OrderItem;
import com.gateway.model.Product;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

// Order rules: create an order from catalogue products and look orders up.
public class OrderService {

    private final OrderRepository repository;
    private final CustomerService customerService;
    private final ProductCatalog catalog;

    public OrderService(OrderRepository repository, CustomerService customerService, ProductCatalog catalog) {
        this.repository = repository;
        this.customerService = customerService;
        this.catalog = catalog;
        IdGenerator.ORDER.advancePast(
                repository.findAll().stream().map(Order::getOrderId).collect(Collectors.toList()));
    }

    public List<Product> getProducts() {
        return catalog.getProducts();
    }

    // quantitiesByProductId: productId -> quantity. Prices always come from the catalogue.
    public Order createOrder(String customerId, Map<String, Integer> quantitiesByProductId) {
        customerService.getCustomer(customerId); // throws NotFoundException for unknown customers
        if (quantitiesByProductId == null || quantitiesByProductId.isEmpty()) {
            throw new ValidationException("Please select at least one product.");
        }
        List<OrderItem> items = new ArrayList<OrderItem>();
        for (Map.Entry<String, Integer> entry : quantitiesByProductId.entrySet()) {
            Product product = catalog.getProduct(entry.getKey());
            items.add(new OrderItem(product.getProductId(), product.getName(), product.getPrice(), entry.getValue()));
        }
        Order order = new Order(IdGenerator.ORDER.next(), customerId, items);
        repository.save(order);
        return order;
    }

    public Order getOrder(String orderId) {
        return repository.findById(orderId)
                .orElseThrow(() -> new NotFoundException("Order", orderId));
    }

    public List<Order> getOrdersByCustomer(String customerId) {
        return repository.findByCustomerId(customerId);
    }
}
