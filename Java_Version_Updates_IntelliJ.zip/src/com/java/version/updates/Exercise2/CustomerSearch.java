package com.java.version.updates.exercise2;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class CustomerSearch {
    public static void main(String[] args) {
        List<Customer> cus=Arrays.asList(
            new Customer(1,"Akhil"),
            new Customer(2,"Priya"),
            new Customer(3,"Rahul")
        );

        Optional<Customer> res=cus.stream()
            .filter(c -> c.getId()==2)
            .findFirst();

        System.out.println(res.map(c -> c.getName()).orElse("Customer not found"));

        Optional<Customer> miss=cus.stream()
            .filter(c -> c.getId()==9)
            .findFirst();

        System.out.println(miss.map(c -> c.getName()).orElse("Customer not found"));
    }
}
