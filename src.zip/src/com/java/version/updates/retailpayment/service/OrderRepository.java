package com.java.version.updates.retailpayment.service;

import com.java.version.updates.retailpayment.model.Order;
import com.java.version.updates.retailpayment.model.OrderItem;

import java.math.BigDecimal;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

// Saved as one row per product line: rows with the same orderId belong to the same order.
public final class OrderRepository extends CsvRepository<Order, String> {

    public OrderRepository(Path file) {
        super(file, "orderId,customerId,productId,productName,unitPrice,quantity", Order::getOrderId);
        load();
    }

    public List<Order> findByCustomerId(String customerId) {
        return findAll().stream()
                .filter(order -> order.getCustomerId().equals(customerId))
                .collect(Collectors.toList());
    }

    @Override
    protected List<String[]> toRows(Order order) {
        List<String[]> rows = new ArrayList<String[]>();
        for (OrderItem item : order.getItems()) {
            rows.add(new String[]{
                    order.getOrderId(),
                    order.getCustomerId(),
                    item.getProductId(),
                    item.getProductName(),
                    item.getUnitPrice().toPlainString(),
                    String.valueOf(item.getQuantity())
            });
        }
        return rows;
    }

    // Groups the rows by orderId and rebuilds each Order from its product lines.
    @Override
    protected List<Order> fromRows(List<String[]> rows) {
        Map<String, List<String[]>> rowsByOrder = new LinkedHashMap<String, List<String[]>>();
        for (String[] row : rows) {
            List<String[]> group = rowsByOrder.get(row[0]);
            if (group == null) {
                group = new ArrayList<String[]>();
                rowsByOrder.put(row[0], group);
            }
            group.add(row);
        }

        List<Order> orders = new ArrayList<Order>();
        for (List<String[]> group : rowsByOrder.values()) {
            try {
                orders.add(buildOrder(group));
            } catch (RuntimeException e) {
                logSkipped(e);
            }
        }
        return orders;
    }

    private Order buildOrder(List<String[]> group) {
        List<OrderItem> items = new ArrayList<OrderItem>();
        for (String[] row : group) {
            items.add(new OrderItem(row[2], row[3], new BigDecimal(row[4]), Integer.parseInt(row[5])));
        }
        return new Order(group.get(0)[0], group.get(0)[1], items);
    }
}
