package com.java.version.updates.retailpayment.service;
import com.java.version.updates.retailpayment.exception.GatewayException;
import com.java.version.updates.retailpayment.model.*;
import com.java.version.updates.retailpayment.payment.PaymentMethod;
import com.java.version.updates.retailpayment.repository.TransactionRepository;
import com.java.version.updates.retailpayment.util.Refundable;
import com.java.version.updates.retailpayment.util.TransactionStatus;
import java.math.*;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.io.*;
import java.util.Base64;

public class PaymentGatewayService implements Refundable {
    private static final BigDecimal FEE_RATE = new BigDecimal("0.01");
    private static final AtomicLong CUSTOMER_SEQ = new AtomicLong(100), ORDER_SEQ = new AtomicLong(100), TXN_SEQ = new AtomicLong(1000);
    private final Map<String, Customer> customers = new LinkedHashMap<String, Customer>();
    private final Map<String, Order> orders = new LinkedHashMap<String, Order>();
    private final List<Product> products = new ArrayList<Product>();
    private final TransactionRepository repo;
    private final Path customerFile = Paths.get("data/customers.csv");
    private final Path orderFile = Paths.get("data/orders.csv");

    public PaymentGatewayService(TransactionRepository repo) { this.repo = repo; seedProducts(); }
    private void seedProducts() {
        products.add(new Product(1,"P101","Wireless Mouse",new BigDecimal("799.00")));
        products.add(new Product(2,"P102","Mechanical Keyboard",new BigDecimal("2499.00")));
        products.add(new Product(3,"P103","USB-C Hub",new BigDecimal("1599.00")));
        products.add(new Product(4,"P104","Headphones",new BigDecimal("1999.00")));
        products.add(new Product(5,"P105","Laptop Stand",new BigDecimal("1299.00")));
        products.add(new Product(6,"P106","Webcam",new BigDecimal("1799.00")));
    }
    public Customer registerCustomer(String name, String email) throws GatewayException {
        if (name == null || name.trim().isEmpty()) throw new GatewayException("Name is required.");
        if (email == null || !email.matches("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$"))
            throw new GatewayException("Please enter a valid email address.");
        for (Customer c : customers.values())
            if (c.getEmail().equalsIgnoreCase(email.trim())) throw new GatewayException("That email is already registered. Use your email to access your account.");
        Customer c = new Customer("CUS" + CUSTOMER_SEQ.getAndIncrement(), name, email);
        customers.put(c.getCustomerId(), c);
        saveCustomers();
        return c;
    }
    public Customer findCustomerByEmail(String email) throws GatewayException {
        if (email == null || email.trim().isEmpty()) throw new GatewayException("Please enter your registered email.");
        for (Customer c : customers.values()) {
            if (c.getEmail().equalsIgnoreCase(email.trim())) return c;
        }
        throw new GatewayException("No customer is registered with that email. Please check the email or register first.");
    }
    public List<Product> getProducts() { return new ArrayList<Product>(products); }
    public Product getProductByNumber(int n) {
        return products.stream().filter(p -> p.getDisplayNumber() == n).findFirst().orElse(null);
    }
    public Order createOrder(String customerId, List<OrderItem> items) throws GatewayException {
        if (!customers.containsKey(customerId)) throw new GatewayException("Customer session not found. Please register again.");
        if (items == null || items.isEmpty()) throw new GatewayException("Please select at least one product.");
        for (OrderItem item : items) {
            if (item == null || getProducts().stream().noneMatch(p -> p.getProductId().equals(item.getProduct().getProductId())))
                throw new GatewayException("Order contains an unavailable product.");
        }
        Order o = new Order("ORD" + ORDER_SEQ.getAndIncrement(), customerId, items);
        orders.put(o.getOrderId(), o);
        saveOrders();
        return o;
    }
    public List<Order> getCustomerOrders(String id) {
        return orders.values().stream().filter(o -> o.getCustomerId().equals(id)).collect(Collectors.toList());
    }
    public List<Order> getUnpaidCustomerOrders(String id) {
        return getCustomerOrders(id).stream().filter(o -> !isOrderPaid(o.getOrderId())).collect(Collectors.toList());
    }
    public boolean isOrderPaid(String id) {
        return repo.findAll().stream().anyMatch(t -> t.getOrderId().equals(id)
                && (t.getStatus() == TransactionStatus.SUCCESS || t.getStatus() == TransactionStatus.REFUNDED));
    }
    public void loadAllData() {
        loadCustomers();
        loadOrders();
        repo.load();
        CUSTOMER_SEQ.set(Math.max(100L, nextNumber(customers.keySet(), "CUS", 100L)));
        ORDER_SEQ.set(Math.max(100L, nextNumber(orders.keySet(), "ORD", 100L)));
        long maxTxn = repo.findAll().stream().map(Transaction::getTransactionId).filter(v -> v.startsWith("TXN"))
                .map(v -> v.substring(3)).filter(v -> v.matches("\\d+")).mapToLong(Long::parseLong).max().orElse(999L);
        TXN_SEQ.set(Math.max(1000L, maxTxn + 1));
        // Warn about old/corrupt transaction records that reference missing data.
        for (Transaction t : repo.findAll()) {
            if (!orders.containsKey(t.getOrderId()) || !customers.containsKey(t.getCustomerId()))
                System.out.println("Warning: saved transaction " + t.getTransactionId()
                        + " references a missing order/customer. Check data CSV files.");
        }
    }
    public void saveAllData() {
        saveCustomers();
        saveOrders();
        repo.saveAll();
    }
    /** Backward-compatible names used by the menu. */
    public void loadTransactions() { loadAllData(); }
    public void saveTransactions() { saveAllData(); }

    private long nextNumber(Set<String> ids, String prefix, long fallback) {
        return ids.stream().filter(v -> v.startsWith(prefix)).map(v -> v.substring(prefix.length()))
                .filter(v -> v.matches("\\d+")).mapToLong(Long::parseLong).max().orElse(fallback - 1) + 1;
    }

    private void loadCustomers() {
        customers.clear();
        if (!Files.exists(customerFile)) return;
        try (BufferedReader br = Files.newBufferedReader(customerFile, StandardCharsets.UTF_8)) {
            String line; boolean first = true;
            while ((line = br.readLine()) != null) {
                if (first && line.startsWith("customerId,")) { first = false; continue; }
                first = false; if (line.trim().isEmpty()) continue;
                String[] a = line.split(",", -1);
                if (a.length != 3) { System.out.println("Skipping invalid customer row."); continue; }
                Customer c = new Customer(a[0], decode(a[1]), decode(a[2]));
                customers.put(c.getCustomerId(), c);
            }
        } catch (Exception ex) { throw new IllegalStateException("Could not load customers from " + customerFile + ": " + ex.getMessage(), ex); }
    }

    private void loadOrders() {
        orders.clear();
        if (!Files.exists(orderFile)) return;
        Map<String, List<OrderItem>> grouped = new LinkedHashMap<String, List<OrderItem>>();
        Map<String, String> owners = new LinkedHashMap<String, String>();
        try (BufferedReader br = Files.newBufferedReader(orderFile, StandardCharsets.UTF_8)) {
            String line; boolean first = true;
            while ((line = br.readLine()) != null) {
                if (first && line.startsWith("orderId,")) { first = false; continue; }
                first = false; if (line.trim().isEmpty()) continue;
                String[] a = line.split(",", -1);
                if (a.length != 4) { System.out.println("Skipping invalid order row."); continue; }
                Product product = products.stream().filter(p -> p.getProductId().equals(a[2])).findFirst().orElse(null);
                if (!customers.containsKey(a[1]) || product == null) { System.out.println("Skipping order row with missing customer/product: " + a[0]); continue; }
                int qty = Integer.parseInt(a[3]);
                if (qty <= 0) continue;
                grouped.computeIfAbsent(a[0], k -> new ArrayList<OrderItem>()).add(new OrderItem(product, qty));
                owners.put(a[0], a[1]);
            }
            for (Map.Entry<String, List<OrderItem>> e : grouped.entrySet())
                orders.put(e.getKey(), new Order(e.getKey(), owners.get(e.getKey()), e.getValue()));
        } catch (Exception ex) { throw new IllegalStateException("Could not load orders from " + orderFile + ": " + ex.getMessage(), ex); }
    }

    private void saveCustomers() {
        try {
            Files.createDirectories(customerFile.getParent());
            try (BufferedWriter bw = Files.newBufferedWriter(customerFile, StandardCharsets.UTF_8)) {
                bw.write("customerId,nameBase64,emailBase64"); bw.newLine();
                for (Customer c : customers.values()) {
                    bw.write(c.getCustomerId() + "," + encode(c.getName()) + "," + encode(c.getEmail())); bw.newLine();
                }
            }
        } catch (IOException ex) { throw new IllegalStateException("Could not save customers: " + ex.getMessage(), ex); }
    }

    private void saveOrders() {
        try {
            Files.createDirectories(orderFile.getParent());
            try (BufferedWriter bw = Files.newBufferedWriter(orderFile, StandardCharsets.UTF_8)) {
                bw.write("orderId,customerId,productId,quantity"); bw.newLine();
                for (Order o : orders.values()) for (OrderItem i : o.getItems()) {
                    bw.write(o.getOrderId() + "," + o.getCustomerId() + "," + i.getProduct().getProductId() + "," + i.getQuantity()); bw.newLine();
                }
            }
        } catch (IOException ex) { throw new IllegalStateException("Could not save orders: " + ex.getMessage(), ex); }
    }

    private String encode(String value) { return Base64.getUrlEncoder().withoutPadding().encodeToString(value.getBytes(StandardCharsets.UTF_8)); }
    private String decode(String value) { return new String(Base64.getUrlDecoder().decode(value), StandardCharsets.UTF_8); }
    public Transaction makePayment(String orderId, PaymentMethod method) throws GatewayException {
        Order o = orders.get(orderId);
        if (o == null) throw new GatewayException("Order not found.");
        if (method == null) throw new GatewayException("Please choose a payment method.");
        if (isOrderPaid(orderId)) throw new GatewayException("This order has already been paid successfully.");
        BigDecimal amount = o.getAmount();
        String id = "TXN" + TXN_SEQ.getAndIncrement();
        BigDecimal fee = amount.multiply(FEE_RATE).setScale(2, RoundingMode.HALF_UP);
        BigDecimal net = amount.subtract(fee).setScale(2, RoundingMode.HALF_UP);
        TransactionStatus status; String msg;
        if (!method.validatePayment(amount)) { status = TransactionStatus.FAILED; msg = "Payment details were invalid"; }
        else {
            PaymentResult r = method.processPayment(amount);
            status = r.isSuccessful() ? TransactionStatus.SUCCESS : TransactionStatus.FAILED;
            msg = r.getMessage();
        }
        Transaction t = new Transaction(id,o.getOrderId(),o.getCustomerId(),amount,fee,net,method.getPaymentType(),
                status,LocalDateTime.now(),null,msg);
        repo.save(t); repo.saveAll(); return t;
    }
    public Transaction getTransaction(String id) throws GatewayException {
        Optional<Transaction> t = repo.findById(id);
        if (!t.isPresent()) throw new GatewayException("Transaction not found: " + id);
        return t.get();
    }
    public List<Transaction> getAllTransactions() { return repo.findAll(); }
    public List<Transaction> getCustomerHistory(String id) {
        return repo.findAll().stream().filter(t -> t.getCustomerId().equals(id)).collect(Collectors.toList());
    }
    public List<Transaction> getRefundableCustomerTransactions(String id) {
        return getCustomerHistory(id).stream().filter(t -> t.getStatus() == TransactionStatus.SUCCESS).collect(Collectors.toList());
    }
    @Override public Transaction refund(String id) throws GatewayException {
        Transaction t = getTransaction(id);
        if (t.getStatus() == TransactionStatus.REFUNDED) throw new GatewayException("This payment has already been refunded.");
        if (t.getStatus() != TransactionStatus.SUCCESS) throw new GatewayException("Only successful payments can be refunded.");
        t.markRefunded(); repo.save(t); repo.saveAll(); return t;
    }
    public void printReport() {
        List<Transaction> all = repo.findAll();
        long ok = all.stream().filter(t -> t.getStatus() == TransactionStatus.SUCCESS).count();
        long fail = all.stream().filter(t -> t.getStatus() == TransactionStatus.FAILED).count();
        long refunded = all.stream().filter(t -> t.getStatus() == TransactionStatus.REFUNDED).count();
        BigDecimal gross = all.stream().filter(t -> t.getStatus() == TransactionStatus.SUCCESS)
                .map(Transaction::getAmount).reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal refunds = all.stream().filter(t -> t.getStatus() == TransactionStatus.REFUNDED)
                .map(Transaction::getAmount).reduce(BigDecimal.ZERO, BigDecimal::add);
        System.out.println("\n================ PAYMENT REPORT ================");
        System.out.println("Total attempts       : " + all.size());
        System.out.println("Currently successful : " + ok);
        System.out.println("Failed               : " + fail);
        System.out.println("Refunded             : " + refunded);
        System.out.println("Successful gross     : Rs. " + gross.setScale(2, RoundingMode.HALF_UP));
        System.out.println("Refunded total       : Rs. " + refunds.setScale(2, RoundingMode.HALF_UP));
        System.out.println("=================================================");
    }
}
