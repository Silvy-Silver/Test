package com.ecommerce.assignment14;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class CustomerOrderItems {
    public static void main(String[] args) {
        Product laptop = new Product("Laptop");
        Product mouse = new Product("Mouse");
        Product keyboard = new Product("Keyboard");
        Product headset = new Product("Headset");

        List<Order> orders = List.of(
            new Order("ORD-101", List.of(
                new OrderItem(laptop, 1), new OrderItem(mouse, 2))),
            new Order("ORD-102", List.of(
                new OrderItem(keyboard, 1), new OrderItem(mouse, 1))),
            new Order("ORD-103", List.of(
                new OrderItem(laptop, 1), new OrderItem(headset, 1)))
        );

        List<OrderItem> allItems = orders.stream()
            .flatMap(o -> o.getItems().stream())
            .toList();

        System.out.println("All product entries:");
        allItems.stream()
            .map(i -> i.getProduct().getName())
            .forEach(System.out::println);

        List<String> uniqueProducts = allItems.stream()
            .map(i -> i.getProduct().getName())
            .distinct()
            .sorted()
            .toList();
        System.out.println("Distinct products: " + uniqueProducts);
        System.out.println("Total item entries: " + allItems.size());

        Map<String, Long> occurrences = allItems.stream()
            .map(i -> i.getProduct().getName())
            .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

        System.out.println("Products appearing in multiple orders:");
        occurrences.entrySet().stream()
            .filter(e -> e.getValue() > 1)
            .sorted(Map.Entry.comparingByKey())
            .forEach(e -> System.out.println(e.getKey() + " appears " + e.getValue() + " times"));
    }
}
