package com.java.version.updates.retailpayment.model;

import com.java.version.updates.retailpayment.util.TransactionStatus;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Transaction {
    private final String transactionId;
    private final String orderId;
    private final String customerId;
    private final BigDecimal amount;
    private final BigDecimal gatewayFee;
    private final BigDecimal netAmount;
    private final String paymentType;
    private TransactionStatus status;
    private final LocalDateTime createdAt;
    private LocalDateTime refundedAt;
    private String message;

    public Transaction(String transactionId, String orderId, String customerId,
                       BigDecimal amount, BigDecimal gatewayFee, BigDecimal netAmount,
                       String paymentType, TransactionStatus status, LocalDateTime createdAt,
                       LocalDateTime refundedAt, String message) {
        this.transactionId = transactionId;
        this.orderId = orderId;
        this.customerId = customerId;
        this.amount = amount;
        this.gatewayFee = gatewayFee;
        this.netAmount = netAmount;
        this.paymentType = paymentType;
        this.status = status;
        this.createdAt = createdAt;
        this.refundedAt = refundedAt;
        this.message = message == null ? "" : message;
    }

    public String getTransactionId() { return transactionId; }
    public String getOrderId() { return orderId; }
    public String getCustomerId() { return customerId; }
    public BigDecimal getAmount() { return amount; }
    public BigDecimal getGatewayFee() { return gatewayFee; }
    public BigDecimal getNetAmount() { return netAmount; }
    public String getPaymentType() { return paymentType; }
    public TransactionStatus getStatus() { return status; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public LocalDateTime getRefundedAt() { return refundedAt; }
    public String getMessage() { return message; }

    public void markRefunded() {
        if (status != TransactionStatus.SUCCESS) {
            throw new IllegalStateException("Only successful transactions can be refunded.");
        }
        status = TransactionStatus.REFUNDED;
        refundedAt = LocalDateTime.now();
        message = "Full refund completed";
    }

    public String toCsv() {
        return clean(transactionId) + "," + clean(orderId) + "," + clean(customerId) + ","
                + amount.toPlainString() + "," + gatewayFee.toPlainString() + ","
                + netAmount.toPlainString() + "," + clean(paymentType) + "," + status.name() + ","
                + createdAt.toString() + "," + (refundedAt == null ? "" : refundedAt.toString())
                + "," + clean(message);
    }

    public static Transaction fromCsv(String line) {
        String[] p = line.split(",", -1);
        if (p.length != 11) {
            throw new IllegalArgumentException("Invalid transaction CSV row.");
        }
        return new Transaction(p[0], p[1], p[2], new BigDecimal(p[3]), new BigDecimal(p[4]),
                new BigDecimal(p[5]), p[6], TransactionStatus.valueOf(p[7]),
                LocalDateTime.parse(p[8]), p[9].isEmpty() ? null : LocalDateTime.parse(p[9]), p[10]);
    }

    private static String clean(String value) {
        return value == null ? "" : value.replace(",", " ").replace("\n", " ").replace("\r", " ");
    }

    @Override
    public String toString() {
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        return "Transaction ID: " + transactionId
                + " | Order: " + orderId
                + " | Customer: " + customerId
                + " | Amount: Rs. " + amount.toPlainString()
                + " | Fee: Rs. " + gatewayFee.toPlainString()
                + " | Net: Rs. " + netAmount.toPlainString()
                + " | Method: " + paymentType
                + " | Status: " + status
                + " | Created: " + createdAt.format(fmt)
                + (refundedAt == null ? "" : " | Refunded: " + refundedAt.format(fmt))
                + " | Message: " + message;
    }
}
