package com.java.version.updates.retailpayment.repository;

import java.util.List;
import java.util.Optional;

public interface GenericRepository<T, ID> {
    void save(T item);
    Optional<T> findById(ID id);
    List<T> findAll();
}
