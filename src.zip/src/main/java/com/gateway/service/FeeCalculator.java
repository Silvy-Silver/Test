package com.gateway.service;

import com.gateway.util.MoneyUtil;

import java.math.BigDecimal;

/** Illustrative gateway fee: 1% of the payment, rounded HALF_UP to 2 decimals. Not a real provider's rate. */
public final class FeeCalculator {

    public static final BigDecimal DEFAULT_RATE = new BigDecimal("0.01");

    private FeeCalculator() {
    }

    public static BigDecimal feeFor(BigDecimal amount) {
        return feeFor(amount, DEFAULT_RATE);
    }

    public static BigDecimal feeFor(BigDecimal amount, BigDecimal rate) {
        return MoneyUtil.scale(amount.multiply(rate));
    }
}
