package com.gateway.model;

import java.time.LocalDateTime;

// Something that can be refunded in full.
public interface Refundable {

    boolean isRefundable();

    // Throws com.gateway.exception.RefundException: if {@link #isRefundable()} is false
    void refund(LocalDateTime refundedAt);
}
