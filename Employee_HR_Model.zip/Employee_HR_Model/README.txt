Employee HR Model - Java

Files:
src/com/acme/hr/model/Employee.java
src/Main.java

Open the Employee_HR_Model folder in IntelliJ IDEA and run Main.java.
Requires Java 11 or newer because String.isBlank() is used.
