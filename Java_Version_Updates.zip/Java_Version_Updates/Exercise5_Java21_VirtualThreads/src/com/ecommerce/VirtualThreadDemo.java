package com.ecommerce;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class VirtualThreadDemo {
    public static void main(String[] args) throws InterruptedException {
        try(ExecutorService ex=Executors.newVirtualThreadPerTaskExecutor()) {
            for(int i=1;i<=3;i++) {
                ex.submit(new ApiTask(i));
            }

            ex.shutdown();
            if(!ex.awaitTermination(2,TimeUnit.SECONDS)) {
                System.out.println("Timed out waiting for API calls");
                ex.shutdownNow();
            }
        }
    }
}
