package com.java.version.updates.retailpayment.service;


import com.java.version.updates.retailpayment.exception.NotFoundException;
import com.java.version.updates.retailpayment.exception.ValidationException;
import com.java.version.updates.retailpayment.model.Customer;
import com.java.version.updates.retailpayment.model.Validation;

import java.util.stream.Collectors;

// Customer rules: register (unique email) and find by email or ID.
public class CustomerService {

    private final CustomerRepository repository;

    public CustomerService(CustomerRepository repository) {
        this.repository = repository;
        // Continue numbering after the highest saved ID (keeps IDs unique after a restart).
        IdGenerator.CUSTOMER.advancePast(
                repository.findAll().stream().map(Customer::getCustomerId).collect(Collectors.toList()));
    }

    // Validates first, so a rejected request never uses up an ID.
    public Customer register(String name, String email) {
        // Validate first so a rejected request never consumes an ID.
        String cleanName = Validation.requireNotBlank(name, "Name");
        String cleanEmail = Validation.requireEmail(email);
        if (repository.findByEmail(cleanEmail).isPresent()) {
            throw new ValidationException("That email is already registered: " + cleanEmail);
        }
        Customer customer = new Customer(IdGenerator.CUSTOMER.next(), cleanName, cleanEmail);
        repository.save(customer);
        return customer;
    }

    public Customer findByEmail(String email) {
        String cleanEmail = Validation.requireNotBlank(email, "Email");
        return repository.findByEmail(cleanEmail)
                .orElseThrow(() -> new NotFoundException("Customer with email", cleanEmail));
    }

    public Customer getCustomer(String customerId) {
        return repository.findById(customerId)
                .orElseThrow(() -> new NotFoundException("Customer", customerId));
    }
}
