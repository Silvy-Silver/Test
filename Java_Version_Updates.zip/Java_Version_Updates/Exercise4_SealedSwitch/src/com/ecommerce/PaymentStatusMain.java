package com.ecommerce;

public class PaymentStatusMain {
    static String getLabel(PaymentResult res) {
        return switch(res) {
            case PaymentSuccess s -> "Payment successful: "+s.getTransactionId();
            case PaymentFailure f -> "Payment failed: "+f.getReason();
        };
    }

    public static void main(String[] args) {
        PaymentResult a=new PaymentSuccess("TX123");
        PaymentResult b=new PaymentFailure("Insufficient balance");

        System.out.println(getLabel(a));
        System.out.println(getLabel(b));
    }
}
