package com.gateway.payment;

import com.gateway.model.PaymentType;

import java.math.BigDecimal;
import java.util.regex.Pattern;

public class WalletPayment extends PaymentMethod {

    private static final Pattern WALLET_ID = Pattern.compile("^WLT-[A-Z0-9]{4,12}$", Pattern.CASE_INSENSITIVE);

    public WalletPayment(String walletId) {
        super(PaymentType.WALLET, walletId, WALLET_ID);
    }

    @Override
    public PaymentResult processPayment(BigDecimal amount) {
        return simulateProvider();
    }
}
