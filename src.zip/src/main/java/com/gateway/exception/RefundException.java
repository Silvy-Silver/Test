package com.gateway.exception;

// A refund was requested for a transaction that is not eligible (failed, or already refunded).
public class RefundException extends GatewayException {

    private static final long serialVersionUID = 1L;

    public RefundException(String message) {
        super(message);
    }
}
