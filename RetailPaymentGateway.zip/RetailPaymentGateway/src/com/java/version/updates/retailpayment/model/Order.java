package com.java.version.updates.retailpayment.model;

import java.math.BigDecimal;

public class Order {
    private final String orderId;
    private final String customerId;
    private final BigDecimal amount;

    public Order(String orderId, String customerId, BigDecimal amount) {
        if (orderId == null || orderId.trim().isEmpty()) {
            throw new IllegalArgumentException("Order ID is required.");
        }
        if (customerId == null || customerId.trim().isEmpty()) {
            throw new IllegalArgumentException("Customer ID is required.");
        }
        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Order amount must be greater than zero.");
        }
        this.orderId = orderId.trim();
        this.customerId = customerId.trim();
        this.amount = amount.setScale(2, java.math.RoundingMode.HALF_UP);
    }

    public String getOrderId() { return orderId; }
    public String getCustomerId() { return customerId; }
    public BigDecimal getAmount() { return amount; }
}
