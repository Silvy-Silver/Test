package com.java.version.updates.retailpayment.payment;

import com.java.version.updates.retailpayment.model.PaymentResult;

import java.math.BigDecimal;

public class CardPayment extends PaymentMethod {
    private final String cardAlias;

    public CardPayment(String cardAlias) {
        this.cardAlias = cardAlias == null ? "" : cardAlias.trim();
    }

    @Override
    public boolean validatePayment(BigDecimal amount) {
        return amount != null && amount.compareTo(BigDecimal.ZERO) > 0
                && cardAlias.matches("CARD-DEMO-[A-Za-z0-9-]{2,20}");
    }

    @Override
    public String getPaymentType() { return "CARD_SIMULATION"; }

    @Override
    public PaymentResult processPayment(BigDecimal amount) {
        if ("CARD-DEMO-DECLINE".equalsIgnoreCase(cardAlias)) {
            return new PaymentResult(false, "Simulated card provider decline");
        }
        return new PaymentResult(true, "Simulated card payment approved");
    }
}
