package com.java.version.updates.retailpayment.service;

import com.java.version.updates.retailpayment.exception.GatewayException;
import com.java.version.updates.retailpayment.model.Customer;
import com.java.version.updates.retailpayment.model.Order;
import com.java.version.updates.retailpayment.model.PaymentResult;
import com.java.version.updates.retailpayment.model.Transaction;
import com.java.version.updates.retailpayment.payment.PaymentMethod;
import com.java.version.updates.retailpayment.repository.TransactionRepository;
import com.java.version.updates.retailpayment.util.Refundable;
import com.java.version.updates.retailpayment.util.TransactionStatus;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;

public class PaymentGatewayService implements Refundable {
    private static final BigDecimal FEE_RATE = new BigDecimal("0.01");
    private static final AtomicLong NEXT_ID = new AtomicLong(1000);

    private final Map<String, Customer> customers = new HashMap<String, Customer>();
    private final Map<String, Order> orders = new HashMap<String, Order>();
    private final TransactionRepository transactions;

    public PaymentGatewayService(TransactionRepository transactions) {
        this.transactions = transactions;
    }

    public void loadTransactions() {
        transactions.load();
        long max = transactions.findAll().stream()
                .map(Transaction::getTransactionId)
                .filter(id -> id.startsWith("TXN"))
                .map(id -> id.substring(3))
                .filter(s -> s.matches("\\d+"))
                .mapToLong(Long::parseLong)
                .max().orElse(1000L);
        NEXT_ID.set(Math.max(NEXT_ID.get(), max + 1));
    }

    public void saveTransactions() {
        transactions.saveAll();
    }

    public void registerCustomer(Customer customer) throws GatewayException {
        if (customers.containsKey(customer.getCustomerId())) {
            throw new GatewayException("Customer ID already exists.");
        }
        customers.put(customer.getCustomerId(), customer);
    }

    public void createOrder(Order order) throws GatewayException {
        if (!customers.containsKey(order.getCustomerId())) {
            throw new GatewayException("Customer does not exist. Register the customer first.");
        }
        if (orders.containsKey(order.getOrderId())) {
            throw new GatewayException("Order ID already exists.");
        }
        orders.put(order.getOrderId(), order);
    }

    public Transaction makePayment(String orderId, PaymentMethod method) throws GatewayException {
        Order order = orders.get(orderId);
        if (order == null) {
            throw new GatewayException("Order not found: " + orderId);
        }
        BigDecimal amount = order.getAmount();
        String txnId = "TXN" + NEXT_ID.getAndIncrement();
        BigDecimal fee = amount.multiply(FEE_RATE).setScale(2, RoundingMode.HALF_UP);
        BigDecimal net = amount.subtract(fee).setScale(2, RoundingMode.HALF_UP);

        TransactionStatus status;
        String message;
        if (!method.validatePayment(amount)) {
            status = TransactionStatus.FAILED;
            message = "Payment validation failed";
        } else {
            PaymentResult result = method.processPayment(amount);
            status = result.isSuccessful() ? TransactionStatus.SUCCESS : TransactionStatus.FAILED;
            message = result.getMessage();
        }

        Transaction txn = new Transaction(txnId, order.getOrderId(), order.getCustomerId(),
                amount, fee, net, method.getPaymentType(), status, LocalDateTime.now(), null, message);
        transactions.save(txn);
        transactions.saveAll();
        return txn;
    }

    public Transaction getTransaction(String id) throws GatewayException {
        Optional<Transaction> txn = transactions.findById(id);
        if (!txn.isPresent()) {
            throw new GatewayException("Transaction not found: " + id);
        }
        return txn.get();
    }

    public List<Transaction> getAllTransactions() {
        return transactions.findAll();
    }

    public List<Transaction> getCustomerHistory(String customerId) {
        return transactions.findAll().stream()
                .filter(txn -> txn.getCustomerId().equals(customerId))
                .collect(Collectors.toList());
    }

    @Override
    public Transaction refund(String transactionId) throws GatewayException {
        Transaction txn = getTransaction(transactionId);
        if (txn.getStatus() == TransactionStatus.REFUNDED) {
            throw new GatewayException("This transaction has already been refunded.");
        }
        if (txn.getStatus() != TransactionStatus.SUCCESS) {
            throw new GatewayException("Only successful transactions can be refunded.");
        }
        txn.markRefunded();
        transactions.save(txn);
        transactions.saveAll();
        return txn;
    }

    public void printReport() {
        List<Transaction> all = transactions.findAll();
        long success = all.stream().filter(t -> t.getStatus() == TransactionStatus.SUCCESS).count();
        long failed = all.stream().filter(t -> t.getStatus() == TransactionStatus.FAILED).count();
        long refunded = all.stream().filter(t -> t.getStatus() == TransactionStatus.REFUNDED).count();

        BigDecimal collected = all.stream()
                .filter(t -> t.getStatus() == TransactionStatus.SUCCESS)
                .map(Transaction::getAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal refundedTotal = all.stream()
                .filter(t -> t.getStatus() == TransactionStatus.REFUNDED)
                .map(Transaction::getAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        System.out.println("========== PAYMENT REPORT ==========");
        System.out.println("Total attempts  : " + all.size());
        System.out.println("Successful      : " + success);
        System.out.println("Failed          : " + failed);
        System.out.println("Refunded        : " + refunded);
        System.out.println("Successful gross: Rs. " + collected.setScale(2, RoundingMode.HALF_UP));
        System.out.println("Refunded total  : Rs. " + refundedTotal.setScale(2, RoundingMode.HALF_UP));
        System.out.println("====================================");
        all.forEach(System.out::println);
    }
}
