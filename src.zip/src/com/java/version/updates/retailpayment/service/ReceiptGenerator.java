package com.java.version.updates.retailpayment.service;

import com.java.version.updates.retailpayment.model.Transaction;

// Turns a transaction into printable text. Other formats (HTML, PDF) can be added by implementing this.
public interface ReceiptGenerator {

    String generate(Transaction transaction);
}
