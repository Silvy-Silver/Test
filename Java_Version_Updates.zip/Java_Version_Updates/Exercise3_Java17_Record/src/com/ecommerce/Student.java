package com.ecommerce;

public record Student(String name,int age) {
    public Student {
        if(name==null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Name is required");
        }
        if(age<1) {
            throw new IllegalArgumentException("Age must be positive");
        }
    }
}
