package com.gateway.ui;

import java.io.InputStream;
import java.io.PrintStream;
import java.util.Scanner;

/** All keyboard reading in one place, so the menu code never touches Scanner directly. */
public class ConsoleInput {

    private final Scanner scanner;
    private final PrintStream out;

    public ConsoleInput(InputStream in, PrintStream out) {
        this.scanner = new Scanner(in);
        this.out = out;
    }

    /** @throws java.util.NoSuchElementException when the input stream has ended */
    public String readLine(String prompt) {
        out.print(prompt);
        return scanner.nextLine().trim();
    }

    public int readInt(String prompt) {
        while (true) {
            String text = readLine(prompt);
            try {
                return Integer.parseInt(text);
            } catch (NumberFormatException e) {
                out.println("Please enter a whole number.");
            }
        }
    }

    public boolean yesNo(String prompt) {
        while (true) {
            String text = readLine(prompt);
            if (text.equalsIgnoreCase("y") || text.equalsIgnoreCase("yes")) {
                return true;
            }
            if (text.equalsIgnoreCase("n") || text.equalsIgnoreCase("no")) {
                return false;
            }
            out.println("Please enter y or n.");
        }
    }
}
