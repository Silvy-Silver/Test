package com.java.version.updates.retailpayment.exception;

// Base type for every business-rule failure in the gateway.
// It is unchecked so that service methods stay free of "throws" clauses;
// the console menu catches it in exactly one place.
public class GatewayException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public GatewayException(String message) {
        super(message);
    }
}
