package com.java.version.updates.exercise5;

public class ApiTask implements Runnable {
    private final int id;

    public ApiTask(int id) {
        this.id=id;
    }

    @Override
    public void run() {
        try {
            System.out.println("API call "+id+" started");
            Thread.sleep(1000);
            System.out.println("API call "+id+" finished");
        } catch(InterruptedException e) {
            Thread.currentThread().interrupt();
            System.out.println("API call "+id+" interrupted");
        }
    }
}
