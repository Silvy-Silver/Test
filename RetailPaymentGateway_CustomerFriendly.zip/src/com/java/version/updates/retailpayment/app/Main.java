package com.java.version.updates.retailpayment.app;
import com.java.version.updates.retailpayment.exception.GatewayException;
import com.java.version.updates.retailpayment.model.*;
import com.java.version.updates.retailpayment.payment.*;
import com.java.version.updates.retailpayment.repository.TransactionRepository;
import com.java.version.updates.retailpayment.service.PaymentGatewayService;
import com.java.version.updates.retailpayment.util.ReceiptGenerator;
import java.util.*;

public class Main {
    private static final Scanner SC = new Scanner(System.in);
    private static final PaymentGatewayService SERVICE = new PaymentGatewayService(new TransactionRepository("data/transactions.csv"));

    public static void main(String[] args) {
        SERVICE.loadTransactions();
        System.out.println("========================================");
        System.out.println("       WELCOME TO EVERYDAY RETAIL");
        System.out.println("========================================");
        System.out.println("Loaded " + SERVICE.getAllTransactions().size() + " saved transaction(s).");
        boolean running = true;
        while (running) {
            menu();
            int choice = readInt("Choose an option: ");
            try {
                switch (choice) {
                    case 1: registerCustomer(); break;
                    case 2: browseProducts(); break;
                    case 3: shopAndCreateOrder(); break;
                    case 4: showOrdersByEmail(); break;
                    case 5: payOrderByEmail(); break;
                    case 6: showHistoryByEmail(); break;
                    case 7: viewTransactionById(); break;
                    case 8: refundByEmail(); break;
                    case 9: SERVICE.printReport(); break;
                    case 10: SERVICE.saveTransactions(); running = false; System.out.println("Thank you for shopping with Everyday Retail!"); break;
                    default: System.out.println("Please choose an option from 1 to 10.");
                }
            } catch (GatewayException | IllegalArgumentException ex) {
                System.out.println("Sorry, " + ex.getMessage());
            } catch (Exception ex) {
                System.out.println("Something went wrong: " + ex.getMessage());
            }
            System.out.println();
        }
    }

    private static void menu() {
        System.out.println("\\n--------------- MAIN MENU ---------------");
        System.out.println("1. Register customer");
        System.out.println("2. Browse products");
        System.out.println("3. Shop products / create order");
        System.out.println("4. Find my orders (email)");
        System.out.println("5. Pay for an order (email)");
        System.out.println("6. View my payment history (email)");
        System.out.println("7. View transaction details (transaction ID)");
        System.out.println("8. Request a refund (email)");
        System.out.println("9. Payment report");
        System.out.println("10. Exit");
    }

    private static Customer registerCustomer() throws GatewayException {
        Customer c = SERVICE.registerCustomer(readLine("Your name: "), readLine("Email address: "));
        System.out.println("Welcome, " + c.getName() + "! Your customer ID is " + c.getCustomerId() + ".");
        System.out.println("Use your registered email to find your orders and customer details.");
        return c;
    }

    private static Customer customerByEmail() throws GatewayException {
        String email = readLine("Enter your registered customer email: ");
        Customer c = SERVICE.findCustomerByEmail(email);
        System.out.println("Customer found: " + c.getName() + " | " + c.getEmail() + " | " + c.getCustomerId());
        return c;
    }

    private static void shopAndCreateOrder() throws GatewayException {
        Customer c = customerByEmail();
        createOrder(c);
    }

    private static void browseProducts() {
        System.out.println("\\n--------------- PRODUCT CATALOGUE ---------------");
        System.out.printf("%-5s %-26s %12s%n", "No.", "Product", "Price");
        for (Product p : SERVICE.getProducts())
            System.out.printf("%-5d %-26s Rs. %8s%n", p.getDisplayNumber(), p.getName(), p.getPrice());
    }

    private static void createOrder(Customer c) throws GatewayException {
        browseProducts();
        List<OrderItem> items = new ArrayList<OrderItem>();
        while (true) {
            int no = readInt("Choose product number (0 to finish): ");
            if (no == 0) break;
            Product p = SERVICE.getProductByNumber(no);
            if (p == null) { System.out.println("That product number isn't available."); continue; }
            int qty = readInt("Quantity for " + p.getName() + ": ");
            if (qty <= 0) { System.out.println("Quantity must be at least 1."); continue; }
            items.add(new OrderItem(p, qty));
            System.out.println("Added " + qty + " x " + p.getName() + ".");
            if (!yesNo("Add another product? (y/n): ")) break;
        }
        if (items.isEmpty()) { System.out.println("No products selected; no order was created."); return; }
        Order o = SERVICE.createOrder(c.getCustomerId(), items);
        System.out.println("\\nORDER CREATED");
        System.out.println("Customer: " + c.getName() + " (" + c.getEmail() + ")");
        System.out.println("Order ID: " + o.getOrderId());
        for (OrderItem i : o.getItems())
            System.out.println(i.getQuantity() + " x " + i.getProduct().getName() + " = Rs. " + i.getLineTotal());
        System.out.println("Total payable: Rs. " + o.getAmount());
    }

    private static void showOrdersByEmail() throws GatewayException {
        Customer c = customerByEmail();
        List<Order> list = SERVICE.getCustomerOrders(c.getCustomerId());
        System.out.println("\\n---------------- ORDERS FOR " + c.getName().toUpperCase() + " ----------------");
        if (list.isEmpty()) { System.out.println("No orders found for this customer."); return; }
        System.out.printf("%-12s %-18s %14s %-10s%n", "Order ID", "Items", "Total", "Payment");
        for (Order o : list) {
            System.out.printf("%-12s %-18s Rs. %10s %-10s%n", o.getOrderId(),
                    o.getItems().size() + " product type(s)", o.getAmount(),
                    SERVICE.isOrderPaid(o.getOrderId()) ? "PAID" : "UNPAID");
        }
    }

    private static void payOrderByEmail() throws GatewayException {
        Customer c = customerByEmail();
        List<Order> list = SERVICE.getUnpaidCustomerOrders(c.getCustomerId());
        if (list.isEmpty()) { System.out.println("No unpaid orders found for " + c.getName() + "."); return; }
        System.out.println("\\n---------------- UNPAID ORDERS ----------------");
        for (int i = 0; i < list.size(); i++)
            System.out.println((i + 1) + ". " + list.get(i).getOrderId() + " — Rs. " + list.get(i).getAmount());
        int n = readInt("Which order would you like to pay for? (0 to cancel): ");
        if (n == 0) { System.out.println("Payment cancelled."); return; }
        if (n < 1 || n > list.size()) { System.out.println("Choose a number from the list."); return; }
        Order o = list.get(n - 1);
        System.out.println("Amount to pay: Rs. " + o.getAmount());
        System.out.println("1. UPI   2. Card simulation   3. Wallet");
        int m = readInt("Payment method: ");
        PaymentMethod pm;
        if (m == 1) pm = new UpiPayment(readLine("Demo UPI ID (e.g. demo.user@upi): "));
        else if (m == 2) pm = new CardPayment(readLine("Demo card alias (e.g. CARD-DEMO-1234): "));
        else if (m == 3) pm = new WalletPayment(readLine("Demo wallet ID (e.g. demo-wallet): "));
        else { System.out.println("Unknown payment method; no payment was attempted."); return; }
        ReceiptGenerator.printReceipt(SERVICE.makePayment(o.getOrderId(), pm));
    }

    private static void showHistoryByEmail() throws GatewayException {
        Customer c = customerByEmail();
        List<Transaction> list = SERVICE.getCustomerHistory(c.getCustomerId());
        System.out.println("\\n================ PAYMENT HISTORY FOR " + c.getName().toUpperCase() + " ================");
        if (list.isEmpty()) { System.out.println("No payment history found for this customer."); return; }
        System.out.printf("%-12s %-12s %-17s %12s %-12s%n", "Transaction", "Order", "Method", "Amount", "Status");
        System.out.println("-------------------------------------------------------");
        for (Transaction t : list)
            System.out.printf("%-12s %-12s %-17s Rs. %8s %-12s%n", t.getTransactionId(), t.getOrderId(),
                    t.getPaymentType(), t.getAmount(), t.getStatus());
        System.out.println("Showing " + list.size() + " transaction(s).");
    }

    private static void viewTransactionById() throws GatewayException {
        String id = readLine("Enter transaction ID: ");
        Transaction t = SERVICE.getTransaction(id);
        System.out.println("\\n--------------- TRANSACTION DETAILS ---------------");
        System.out.println("Transaction ID : " + t.getTransactionId());
        System.out.println("Order ID       : " + t.getOrderId());
        System.out.println("Payment method : " + t.getPaymentType());
        System.out.println("Amount         : Rs. " + t.getAmount());
        System.out.println("Gateway fee    : Rs. " + t.getGatewayFee());
        System.out.println("Merchant net   : Rs. " + t.getNetAmount());
        System.out.println("Status         : " + t.getStatus());
        System.out.println("Created at     : " + t.getCreatedAt());
        if (t.getRefundedAt() != null) System.out.println("Refunded at    : " + t.getRefundedAt());
        System.out.println("Details        : " + t.getMessage());
    }

    private static void refundByEmail() throws GatewayException {
        Customer c = customerByEmail();
        List<Transaction> list = SERVICE.getRefundableCustomerTransactions(c.getCustomerId());
        if (list.isEmpty()) { System.out.println("No successful, non-refunded payments are eligible for a refund."); return; }
        System.out.println("\\n---------------- ELIGIBLE PAYMENTS ----------------");
        for (int i = 0; i < list.size(); i++)
            System.out.println((i + 1) + ". " + list.get(i).getTransactionId() + " | Order "
                    + list.get(i).getOrderId() + " | Rs. " + list.get(i).getAmount());
        int n = readInt("Which payment would you like to refund? (0 to cancel): ");
        if (n == 0) { System.out.println("Refund cancelled."); return; }
        if (n < 1 || n > list.size()) { System.out.println("Choose a number from the list."); return; }
        System.out.println("Your simulated full refund has been recorded.");
        ReceiptGenerator.printReceipt(SERVICE.refund(list.get(n - 1).getTransactionId()));
    }

    private static String readLine(String prompt) { System.out.print(prompt); return SC.nextLine().trim(); }
    private static int readInt(String prompt) {
        while (true) { try { return Integer.parseInt(readLine(prompt)); }
            catch (NumberFormatException ex) { System.out.println("Please enter a whole number."); } }
    }
    private static boolean yesNo(String prompt) {
        while (true) {
            String s = readLine(prompt);
            if (s.equalsIgnoreCase("y") || s.equalsIgnoreCase("yes")) return true;
            if (s.equalsIgnoreCase("n") || s.equalsIgnoreCase("no")) return false;
            System.out.println("Please enter y or n.");
        }
    }
}
