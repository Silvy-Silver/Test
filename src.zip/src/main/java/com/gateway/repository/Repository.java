package com.gateway.repository;

import java.util.List;
import java.util.Optional;

/** Generic storage contract: T is the entity type, ID is the type of its identifier. */
public interface Repository<T, ID> {

    /** Inserts a new item or replaces the existing one with the same ID. */
    void save(T item);

    Optional<T> findById(ID id);

    /** All items in insertion order. */
    List<T> findAll();
}
