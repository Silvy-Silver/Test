package com.java.version.updates.retailpayment.service;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

public class ProductCatalog {
    private final Map<String, String> names = new LinkedHashMap<String, String>();
    private final Map<String, BigDecimal> prices = new LinkedHashMap<String, BigDecimal>();

    public ProductCatalog() {
        add("P101", "Wireless Mouse", "799.00");
        add("P102", "Mechanical Keyboard", "2499.00");
        add("P103", "USB-C Hub", "1599.00");
        add("P104", "Headphones", "1999.00");
        add("P105", "Laptop Stand", "1299.00");
        add("P106", "Webcam", "1799.00");
    }

    private void add(String id, String name, String price) {
        names.put(id, name);
        prices.put(id, new BigDecimal(price));
    }

    public Map<String, String> getProducts() {
        return Collections.unmodifiableMap(names);
    }

    public String getProductIdByNumber(int number) {
        if (number < 1 || number > names.size()) {
            return null;
        }

        return names.keySet().toArray(new String[0])[number - 1];
    }

    public String getName(String id) {
        return names.get(id);
    }

    public BigDecimal getPrice(String id) {
        return prices.get(id);
    }

    public boolean contains(String id) {
        return names.containsKey(id);
    }
}
