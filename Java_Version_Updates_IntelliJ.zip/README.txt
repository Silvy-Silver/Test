JAVA VERSION UPDATES - INTELLIJ STRUCTURE

Folder structure:
src/
  com/
    java/
      version/
        updates/
          Exercise1/
          Exercise2/
          Exercise3/
          Exercise4/
          Exercise5/

Each Exercise folder contains its own Java class files directly.
Each class is in its own .java file. Each exercise has its own package.

JDK:
- Exercise1: Java 8+
- Exercise2: Java 8+
- Exercise3: Java 17+
- Exercise4: Java 21
- Exercise5: Java 21

Open the project folder in IntelliJ IDEA and set the Project SDK to the JDK needed for the exercise.
Run EmployeeFilter, CustomerSearch, StudentRecordMain, PaymentStatusMain, or VirtualThreadDemo respectively.
