package com.java.version.updates.retailpayment.model;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
public class Order {
    private final String orderId, customerId;
    private final List<OrderItem> items;
    private final BigDecimal amount;
    public Order(String orderId, String customerId, List<OrderItem> items) {
        if (orderId == null || orderId.trim().isEmpty() || customerId == null || customerId.trim().isEmpty())
            throw new IllegalArgumentException("Order details are required.");
        if (items == null || items.isEmpty()) throw new IllegalArgumentException("An order must contain at least one product.");
        this.orderId = orderId; this.customerId = customerId; this.items = new ArrayList<OrderItem>(items);
        BigDecimal total = BigDecimal.ZERO;
        for (OrderItem item : this.items) total = total.add(item.getLineTotal());
        this.amount = total.setScale(2, RoundingMode.HALF_UP);
    }
    public String getOrderId() { return orderId; }
    public String getCustomerId() { return customerId; }
    public List<OrderItem> getItems() { return Collections.unmodifiableList(items); }
    public BigDecimal getAmount() { return amount; }
}
