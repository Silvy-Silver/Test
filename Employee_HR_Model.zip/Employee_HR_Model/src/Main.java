import com.acme.hr.model.Employee;

public class Main{
    public static void main(String[] args){
        Employee e=new Employee(1,"Rahul","IT",50000);

        System.out.println("ID: "+e.getId());
        System.out.println("Name: "+e.getName());
        System.out.println("Department: "+e.getDepartment());
        System.out.println("Salary: "+e.getSalary());

        e.changeDepartment("HR");
        e.updateSalary(55000);

        System.out.println("Updated department: "+e.getDepartment());
        System.out.println("Updated salary: "+e.getSalary());
        System.out.println("Created employees: "+Employee.getCreatedCount());
    }
}
