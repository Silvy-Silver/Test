package com.java.version.updates.retailpayment.app;

import com.java.version.updates.retailpayment.service.CustomerRepository;
import com.java.version.updates.retailpayment.service.OrderRepository;
import com.java.version.updates.retailpayment.service.TransactionRepository;
import com.java.version.updates.retailpayment.service.CustomerService;
import com.java.version.updates.retailpayment.service.OrderService;
import com.java.version.updates.retailpayment.service.PaymentService;
import com.java.version.updates.retailpayment.service.ProductCatalog;
import com.java.version.updates.retailpayment.service.ReportService;
import com.java.version.updates.retailpayment.service.TextReceiptGenerator;


import java.nio.file.Path;
import java.nio.file.Paths;

// Wires the layers together and starts the menu. No business logic lives here.
public final class Main {

    private Main() {
    }

    // Entry point. Optional argument: folder for the CSV files (default ./data).
    public static void main(String[] args) {
        Path dataDir = Paths.get(args.length > 0 ? args[0] : "data");

        // 1) Repositories: load saved data from CSV files.
        CustomerRepository customerRepository = new CustomerRepository(dataDir.resolve("customers.csv"));
        OrderRepository orderRepository = new OrderRepository(dataDir.resolve("orders.csv"));
        TransactionRepository transactionRepository = new TransactionRepository(dataDir.resolve("transactions.csv"));

        // 2) Services: business rules; each one receives what it needs through its constructor.
        CustomerService customerService = new CustomerService(customerRepository);
        OrderService orderService = new OrderService(orderRepository, customerService, new ProductCatalog());
        PaymentService paymentService = new PaymentService(transactionRepository, orderService);
        ReportService reportService = new ReportService(transactionRepository);

        // 3) The menu uses the services. Main contains no business logic.
        new ConsoleApp(customerService, orderService, paymentService, reportService,
                new TextReceiptGenerator(), System.in, System.out).run();
    }
}
