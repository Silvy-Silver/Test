package com.ecommerce.assignment14;

import java.util.List;

public class Order {
    private final String orderId;
    private final List<OrderItem> items;

    public Order(String orderId, List<OrderItem> items) {
        this.orderId = orderId;
        this.items = List.copyOf(items);
    }

    public String getOrderId() { return orderId; }
    public List<OrderItem> getItems() { return items; }
}
