# Retail Payment Gateway — Customer-Friendly Core Java Mini Project

This console application simulates retail payments only. It does not contact a real bank or payment provider. Never enter real card numbers, CVVs, UPI PINs, or banking credentials.

## Open and run in IntelliJ IDEA
1. Extract this ZIP.
2. Open the extracted project folder in IntelliJ IDEA.
3. Configure a JDK (Java 8 or newer).
4. If needed, right-click `src` and select **Mark Directory as > Sources Root**.
5. Run `com.java.version.updates.retailpayment.app.Main`.

## Data persistence
The app automatically creates a `data` folder in the working directory and stores:
- `customers.csv` — registered customers
- `orders.csv` — orders and their product quantities
- `transactions.csv` — successful and failed payment attempts and refund status

Data is loaded at startup. Customer IDs, order IDs, and transaction IDs continue after the highest saved ID, so restarting the app does not reset them. Customers, orders, and transactions remain available after restarting. Keep the `data` folder with the project; deleting it removes the saved application data.

Customer names and emails are Base64-encoded in `customers.csv` so commas or special characters cannot corrupt the simple file format. The orders file stores one row per product in an order.

## Customer flow
- Register with name and email; the app generates the customer ID.
- Use the registered email to access your orders, history, and refunds.
- Browse the catalogue, choose products and quantities, and let the app calculate the order total.
- Pay for an unpaid order using simulated UPI, card alias, or wallet details.
- View a transaction by its transaction ID.
- Request a full refund for a successful payment. Failed payments cannot be refunded, and duplicate refunds are rejected.
- An order remains paid after a refund; the same order cannot be paid again.

## Demo payment values
- UPI success: `demo.user@upi`
- UPI decline: `decline-demo@upi`
- Card success: `CARD-DEMO-1234`
- Card decline: `CARD-DEMO-DECLINE`
- Wallet success: `demo-wallet`
- Wallet decline: `decline-demo`

The 1% gateway fee is illustrative for the assignment, not a real provider rate. All amounts use `BigDecimal`.
