package com.java.version.updates.exercise3;

public class StudentRecordMain {
    public static void main(String[] args) {
        Student s=new Student("Akhil",21);

        System.out.println(s.name());
        System.out.println(s.age());
        System.out.println(s);
    }
}
