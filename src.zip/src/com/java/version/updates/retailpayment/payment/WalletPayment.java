package com.java.version.updates.retailpayment.payment;

import com.java.version.updates.retailpayment.model.PaymentType;

import java.math.BigDecimal;
import java.util.regex.Pattern;

// Wallet payment using a fictional wallet ID such as WLT-DEMO01.
public class WalletPayment extends PaymentMethod {

    // Valid shape: WLT- followed by 4 to 12 letters or digits.
    private static final Pattern WALLET_ID = Pattern.compile("^WLT-[A-Z0-9]{4,12}$", Pattern.CASE_INSENSITIVE);

    public WalletPayment(String walletId) {
        super(PaymentType.WALLET, walletId, WALLET_ID);
    }

    @Override
    public PaymentResult processPayment(BigDecimal amount) {
        return simulateProvider();
    }
}
