package com.java.version.updates.retailpayment.model;

import com.java.version.updates.retailpayment.exception.ValidationException;

import java.math.BigDecimal;

// One product line inside an order. The price is copied from the catalogue at the time of ordering.
public class OrderItem {

    private final String productId;
    private final String productName;
    private final BigDecimal unitPrice;
    private final int quantity;

    public OrderItem(String productId, String productName, BigDecimal unitPrice, int quantity) {
        this.productId = Validation.requireNotBlank(productId, "Product ID");
        this.productName = Validation.requireNotBlank(productName, "Product name");
        this.unitPrice = Validation.requirePositiveAmount(unitPrice, "Unit price");
        if (quantity <= 0) {
            throw new ValidationException("Quantity must be greater than zero.");
        }
        this.quantity = quantity;
    }

    public String getProductId() {
        return productId;
    }

    public String getProductName() {
        return productName;
    }

    public BigDecimal getUnitPrice() {
        return unitPrice;
    }

    public int getQuantity() {
        return quantity;
    }

    // Price for this line = unit price x quantity.
    public BigDecimal getLineTotal() {
        return MoneyUtil.scale(unitPrice.multiply(BigDecimal.valueOf(quantity)));
    }
}
