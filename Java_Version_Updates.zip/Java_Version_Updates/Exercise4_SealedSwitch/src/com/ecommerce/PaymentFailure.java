package com.ecommerce;

public final class PaymentFailure implements PaymentResult {
    private final String reason;

    public PaymentFailure(String reason) {
        this.reason=reason;
    }

    public String getReason() {
        return reason;
    }
}
