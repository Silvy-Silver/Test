package com.gateway.service;

import com.gateway.exception.DuplicateException;
import com.gateway.exception.NotFoundException;
import com.gateway.exception.ValidationException;
import com.gateway.model.Order;
import com.gateway.model.Transaction;
import com.gateway.model.TransactionStatus;
import com.gateway.payment.PaymentMethod;
import com.gateway.payment.PaymentResult;
import com.gateway.repository.TransactionRepository;
import com.gateway.util.IdGenerator;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/** The payment lifecycle: pay, look up, list history, refund. */
public class PaymentService {

    private final TransactionRepository repository;
    private final OrderService orderService;

    public PaymentService(TransactionRepository repository, OrderService orderService) {
        this.repository = repository;
        this.orderService = orderService;
        IdGenerator.TRANSACTION.advancePast(
                repository.findAll().stream().map(Transaction::getTransactionId).collect(Collectors.toList()));
    }

    /**
     * Pays an order. Bad input is rejected with an exception and leaves no record.
     * A payment the provider declines is a normal outcome: it is stored as a FAILED transaction.
     */
    public Transaction pay(String orderId, PaymentMethod method) {
        if (method == null) {
            throw new ValidationException("Please choose a payment method.");
        }
        Order order = orderService.getOrder(orderId);
        method.validatePayment(order.getAmount());
        if (hasSuccessfulOrRefundedPayment(orderId)) {
            throw new DuplicateException("Order " + orderId + " has already been paid and cannot be paid again.");
        }

        Transaction transaction = new Transaction(
                IdGenerator.TRANSACTION.next(),
                order.getOrderId(),
                order.getCustomerId(),
                order.getAmount(),
                FeeCalculator.feeFor(order.getAmount()),
                method.getPaymentType(),
                LocalDateTime.now());

        PaymentResult result = method.processPayment(order.getAmount());
        if (result.isApproved()) {
            transaction.markSuccess(result.getMessage());
        } else {
            transaction.markFailed(result.getMessage());
        }
        repository.save(transaction);
        return transaction;
    }

    public Transaction refund(String transactionId) {
        Transaction transaction = getTransaction(transactionId);
        transaction.refund(LocalDateTime.now()); // throws RefundException if not eligible
        repository.save(transaction);
        return transaction;
    }

    public Transaction getTransaction(String transactionId) {
        return repository.findById(transactionId)
                .orElseThrow(() -> new NotFoundException("Transaction", transactionId));
    }

    public List<Transaction> getCustomerHistory(String customerId) {
        return repository.findByCustomerId(customerId);
    }

    public List<Transaction> getRefundableTransactions(String customerId) {
        return getCustomerHistory(customerId).stream()
                .filter(Transaction::isRefundable)
                .collect(Collectors.toList());
    }

    public List<Order> getUnpaidOrders(String customerId) {
        return orderService.getOrdersByCustomer(customerId).stream()
                .filter(order -> !hasSuccessfulOrRefundedPayment(order.getOrderId()))
                .collect(Collectors.toList());
    }

    private boolean hasSuccessfulOrRefundedPayment(String orderId) {
        return repository.findByOrderId(orderId).stream()
                .anyMatch(t -> t.getStatus() == TransactionStatus.SUCCESS
                        || t.getStatus() == TransactionStatus.REFUNDED);
    }
}
