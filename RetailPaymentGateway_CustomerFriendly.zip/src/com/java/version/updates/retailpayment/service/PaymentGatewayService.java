package com.java.version.updates.retailpayment.service;
import com.java.version.updates.retailpayment.exception.GatewayException;
import com.java.version.updates.retailpayment.model.*;
import com.java.version.updates.retailpayment.payment.PaymentMethod;
import com.java.version.updates.retailpayment.repository.TransactionRepository;
import com.java.version.updates.retailpayment.util.Refundable;
import com.java.version.updates.retailpayment.util.TransactionStatus;
import java.math.*;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;

public class PaymentGatewayService implements Refundable {
    private static final BigDecimal FEE_RATE = new BigDecimal("0.01");
    private static final AtomicLong CUSTOMER_SEQ = new AtomicLong(100), ORDER_SEQ = new AtomicLong(100), TXN_SEQ = new AtomicLong(1000);
    private final Map<String, Customer> customers = new LinkedHashMap<String, Customer>();
    private final Map<String, Order> orders = new LinkedHashMap<String, Order>();
    private final List<Product> products = new ArrayList<Product>();
    private final TransactionRepository repo;

    public PaymentGatewayService(TransactionRepository repo) { this.repo = repo; seedProducts(); }
    private void seedProducts() {
        products.add(new Product(1,"P101","Wireless Mouse",new BigDecimal("799.00")));
        products.add(new Product(2,"P102","Mechanical Keyboard",new BigDecimal("2499.00")));
        products.add(new Product(3,"P103","USB-C Hub",new BigDecimal("1599.00")));
        products.add(new Product(4,"P104","Headphones",new BigDecimal("1999.00")));
        products.add(new Product(5,"P105","Laptop Stand",new BigDecimal("1299.00")));
        products.add(new Product(6,"P106","Webcam",new BigDecimal("1799.00")));
    }
    public Customer registerCustomer(String name, String email) throws GatewayException {
        for (Customer c : customers.values())
            if (c.getEmail().equalsIgnoreCase(email.trim())) throw new GatewayException("That email is already registered in this session.");
        Customer c = new Customer("CUS" + CUSTOMER_SEQ.getAndIncrement(), name, email);
        customers.put(c.getCustomerId(), c); return c;
    }
    public Customer findCustomerByEmail(String email) throws GatewayException {
        if (email == null || email.trim().isEmpty()) throw new GatewayException("Please enter your registered email.");
        for (Customer c : customers.values()) {
            if (c.getEmail().equalsIgnoreCase(email.trim())) return c;
        }
        throw new GatewayException("No customer is registered with that email in this session. Please register first.");
    }
    public List<Product> getProducts() { return new ArrayList<Product>(products); }
    public Product getProductByNumber(int n) {
        return products.stream().filter(p -> p.getDisplayNumber() == n).findFirst().orElse(null);
    }
    public Order createOrder(String customerId, List<OrderItem> items) throws GatewayException {
        if (!customers.containsKey(customerId)) throw new GatewayException("Customer session not found. Please register again.");
        if (items == null || items.isEmpty()) throw new GatewayException("Please select at least one product.");
        Order o = new Order("ORD" + ORDER_SEQ.getAndIncrement(), customerId, items);
        orders.put(o.getOrderId(), o); return o;
    }
    public List<Order> getCustomerOrders(String id) {
        return orders.values().stream().filter(o -> o.getCustomerId().equals(id)).collect(Collectors.toList());
    }
    public List<Order> getUnpaidCustomerOrders(String id) {
        return getCustomerOrders(id).stream().filter(o -> !isOrderPaid(o.getOrderId())).collect(Collectors.toList());
    }
    public boolean isOrderPaid(String id) {
        return repo.findAll().stream().anyMatch(t -> t.getOrderId().equals(id) && t.getStatus() == TransactionStatus.SUCCESS);
    }
    public void loadTransactions() {
        repo.load();
        long max = repo.findAll().stream().map(Transaction::getTransactionId).filter(s -> s.startsWith("TXN"))
                .map(s -> s.substring(3)).filter(s -> s.matches("\\d+")).mapToLong(Long::parseLong).max().orElse(1000L);
        TXN_SEQ.set(Math.max(TXN_SEQ.get(), max + 1));
    }
    public void saveTransactions() { repo.saveAll(); }
    public Transaction makePayment(String orderId, PaymentMethod method) throws GatewayException {
        Order o = orders.get(orderId);
        if (o == null) throw new GatewayException("Order not found.");
        if (isOrderPaid(orderId)) throw new GatewayException("This order has already been paid successfully.");
        BigDecimal amount = o.getAmount();
        String id = "TXN" + TXN_SEQ.getAndIncrement();
        BigDecimal fee = amount.multiply(FEE_RATE).setScale(2, RoundingMode.HALF_UP);
        BigDecimal net = amount.subtract(fee).setScale(2, RoundingMode.HALF_UP);
        TransactionStatus status; String msg;
        if (!method.validatePayment(amount)) { status = TransactionStatus.FAILED; msg = "Payment details were invalid"; }
        else {
            PaymentResult r = method.processPayment(amount);
            status = r.isSuccessful() ? TransactionStatus.SUCCESS : TransactionStatus.FAILED;
            msg = r.getMessage();
        }
        Transaction t = new Transaction(id,o.getOrderId(),o.getCustomerId(),amount,fee,net,method.getPaymentType(),
                status,LocalDateTime.now(),null,msg);
        repo.save(t); repo.saveAll(); return t;
    }
    public Transaction getTransaction(String id) throws GatewayException {
        Optional<Transaction> t = repo.findById(id);
        if (!t.isPresent()) throw new GatewayException("Transaction not found: " + id);
        return t.get();
    }
    public List<Transaction> getAllTransactions() { return repo.findAll(); }
    public List<Transaction> getCustomerHistory(String id) {
        return repo.findAll().stream().filter(t -> t.getCustomerId().equals(id)).collect(Collectors.toList());
    }
    public List<Transaction> getRefundableCustomerTransactions(String id) {
        return getCustomerHistory(id).stream().filter(t -> t.getStatus() == TransactionStatus.SUCCESS).collect(Collectors.toList());
    }
    @Override public Transaction refund(String id) throws GatewayException {
        Transaction t = getTransaction(id);
        if (t.getStatus() == TransactionStatus.REFUNDED) throw new GatewayException("This payment has already been refunded.");
        if (t.getStatus() != TransactionStatus.SUCCESS) throw new GatewayException("Only successful payments can be refunded.");
        t.markRefunded(); repo.save(t); repo.saveAll(); return t;
    }
    public void printReport() {
        List<Transaction> all = repo.findAll();
        long ok = all.stream().filter(t -> t.getStatus() == TransactionStatus.SUCCESS).count();
        long fail = all.stream().filter(t -> t.getStatus() == TransactionStatus.FAILED).count();
        long refunded = all.stream().filter(t -> t.getStatus() == TransactionStatus.REFUNDED).count();
        BigDecimal gross = all.stream().filter(t -> t.getStatus() == TransactionStatus.SUCCESS)
                .map(Transaction::getAmount).reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal refunds = all.stream().filter(t -> t.getStatus() == TransactionStatus.REFUNDED)
                .map(Transaction::getAmount).reduce(BigDecimal.ZERO, BigDecimal::add);
        System.out.println("\\n================ PAYMENT REPORT ================");
        System.out.println("Total attempts       : " + all.size());
        System.out.println("Currently successful : " + ok);
        System.out.println("Failed               : " + fail);
        System.out.println("Refunded             : " + refunded);
        System.out.println("Successful gross     : Rs. " + gross.setScale(2, RoundingMode.HALF_UP));
        System.out.println("Refunded total       : Rs. " + refunds.setScale(2, RoundingMode.HALF_UP));
        System.out.println("=================================================");
    }
}
