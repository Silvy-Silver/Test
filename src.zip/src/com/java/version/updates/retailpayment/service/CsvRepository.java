package com.java.version.updates.retailpayment.service;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.logging.Logger;

// Reusable generic repository: items are kept in a map for fast lookup (insertion order preserved)
// and written to a CSV file after every change, then reloaded on start-up so data survives restarts.
//
// A concrete repository only describes how one item maps to CSV rows (toRows) and back
// (fromRows), and must call {@link #load()} at the end of its constructor.
public abstract class CsvRepository<T, ID> {

    private static final Logger LOG = Logger.getLogger(CsvRepository.class.getName());

    private final Map<ID, T> items = new LinkedHashMap<ID, T>();
    private final Function<T, ID> idExtractor;
    private final Path file;
    private final String header;
    private final int columnCount;

    protected CsvRepository(Path file, String header, Function<T, ID> idExtractor) {
        this.file = file;
        this.header = header;
        this.idExtractor = idExtractor;
        this.columnCount = header.split(",").length;
    }

    // ---------- what every repository offers ----------

    // Inserts a new item or replaces the one with the same ID, and saves to disk.
    public void save(T item) {
        items.put(idExtractor.apply(item), item);
        flush();
    }

    public Optional<T> findById(ID id) {
        return Optional.ofNullable(items.get(id));
    }

    // All items in insertion order.
    public List<T> findAll() {
        return new ArrayList<T>(items.values());
    }

    // ---------- what each concrete repository describes ----------

    // One item becomes one or more rows (an order has one row per product line).
    protected abstract List<String[]> toRows(T item);

    // Rebuilds items from the saved rows. Use mapEachRow when every row is one item.
    protected abstract List<T> fromRows(List<String[]> rows);

    // Converts each row with the mapper; a bad row is logged and skipped instead of crashing the program.
    protected List<T> mapEachRow(List<String[]> rows, Function<String[], T> mapper) {
        List<T> result = new ArrayList<T>();
        for (String[] row : rows) {
            try {
                result.add(mapper.apply(row));
            } catch (RuntimeException e) {
                logSkipped(e);
            }
        }
        return result;
    }

    protected void logSkipped(RuntimeException e) {
        LOG.warning("Skipping invalid saved row in " + file.getFileName() + ": " + e.getMessage());
    }

    // ---------- file handling ----------

    // Called once at start-up (by the concrete repository). Reads the file, skips bad rows with a warning, and fills the map.
    protected void load() {
        if (!Files.exists(file)) {
            return;
        }
        List<String> lines;
        try {
            lines = Files.readAllLines(file, StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new UncheckedIOException("Could not read " + file, e);
        }
        List<String[]> rows = new ArrayList<String[]>();
        for (int i = 1; i < lines.size(); i++) { // line 0 is the header
            if (lines.get(i).trim().isEmpty()) {
                continue;
            }
            String[] row = parseLine(lines.get(i));
            if (row.length == columnCount) {
                rows.add(row);
            } else {
                LOG.warning("Skipping row " + (i + 1) + " in " + file.getFileName()
                        + ": expected " + columnCount + " columns but found " + row.length);
            }
        }
        for (T item : fromRows(rows)) {
            items.put(idExtractor.apply(item), item); // no flush: nothing has changed yet
        }
    }

    // Rewrites the whole file. Simple and safe for a small learning project; a real database would replace this.
    private void flush() {
        List<String> lines = new ArrayList<String>();
        lines.add(header);
        for (T item : items.values()) {
            for (String[] row : toRows(item)) {
                lines.add(toLine(row));
            }
        }
        try {
            Path parent = file.toAbsolutePath().getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }
            Files.write(file, lines, StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new UncheckedIOException("Could not write " + file, e);
        }
    }

    // ---------- CSV text helpers (quotes and commas inside values) ----------

    private static String toLine(String[] fields) {
        StringBuilder line = new StringBuilder();
        for (int i = 0; i < fields.length; i++) {
            if (i > 0) {
                line.append(',');
            }
            line.append(escape(fields[i]));
        }
        return line.toString();
    }

    private static String escape(String value) {
        if (value == null) {
            return "";
        }
        String singleLine = value.replace('\r', ' ').replace('\n', ' ');
        if (singleLine.contains(",") || singleLine.contains("\"")) {
            return "\"" + singleLine.replace("\"", "\"\"") + "\"";
        }
        return singleLine;
    }

    private static String[] parseLine(String line) {
        List<String> fields = new ArrayList<String>();
        StringBuilder current = new StringBuilder();
        boolean inQuotes = false;
        for (int i = 0; i < line.length(); i++) {
            char ch = line.charAt(i);
            if (ch == '"') {
                if (inQuotes && i + 1 < line.length() && line.charAt(i + 1) == '"') {
                    current.append('"');
                    i++;
                } else {
                    inQuotes = !inQuotes;
                }
            } else if (ch == ',' && !inQuotes) {
                fields.add(current.toString());
                current.setLength(0);
            } else {
                current.append(ch);
            }
        }
        fields.add(current.toString());
        return fields.toArray(new String[0]);
    }
}
