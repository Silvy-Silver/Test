package com.ecommerce;

public class Employee {
    private final String name;
    private final int salary;
    private final boolean active;

    public Employee(String name,int salary,boolean active) {
        this.name=name;
        this.salary=salary;
        this.active=active;
    }

    public String getName() {
        return name;
    }

    public int getSalary() {
        return salary;
    }

    public boolean isActive() {
        return active;
    }
}
