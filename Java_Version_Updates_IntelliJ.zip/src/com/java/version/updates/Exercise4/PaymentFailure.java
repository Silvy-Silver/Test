package com.java.version.updates.exercise4;

public final class PaymentFailure implements PaymentResult {
    private final String reason;

    public PaymentFailure(String reason) {
        this.reason=reason;
    }

    public String getReason() {
        return reason;
    }
}
