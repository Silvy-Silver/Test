package com.gateway.service;

import com.gateway.model.Transaction;
import com.gateway.util.MoneyUtil;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class TextReceiptGenerator implements ReceiptGenerator {

    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private static final String TOP = "========== PAYMENT RECEIPT ==========";
    private static final String BOTTOM = "=====================================";

    @Override
    public String generate(Transaction t) {
        List<String> lines = new ArrayList<String>();
        lines.add(TOP);
        lines.add(line("Order ID", t.getOrderId()));
        lines.add(line("Transaction ID", t.getTransactionId()));
        lines.add(line("Payment Method", t.getPaymentType().getDisplayName()));
        lines.add(line("Amount", MoneyUtil.format(t.getAmount())));
        lines.add(line("Gateway Fee", MoneyUtil.format(t.getGatewayFee())));
        lines.add(line("Merchant Net", MoneyUtil.format(t.getNetAmount())));
        lines.add(line("Status", t.getStatus().name()));
        lines.add(line("Date", t.getCreatedAt().format(DATE_FORMAT)));
        if (t.getRefundedAt() != null) {
            lines.add(line("Refunded At", t.getRefundedAt().format(DATE_FORMAT)));
        }
        lines.add(line("Note", t.getMessage()));
        lines.add(BOTTOM);
        return String.join(System.lineSeparator(), lines);
    }

    private static String line(String label, String value) {
        return String.format("%-15s: %s", label, value);
    }
}
