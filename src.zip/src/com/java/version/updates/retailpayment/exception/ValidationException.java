package com.java.version.updates.retailpayment.exception;

// Input was rejected: bad amount, malformed UPI ID, blank name, and so on.
public class ValidationException extends GatewayException {

    private static final long serialVersionUID = 1L;

    public ValidationException(String message) {
        super(message);
    }
}
