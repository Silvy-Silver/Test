package com.java.version.updates.retailpayment.model;


// A registered shopper. Fields are private and final, so a Customer cannot be changed after it is created.
public class Customer {

    private final String customerId;
    private final String name;
    private final String email;

    // Validation happens here, so an invalid Customer can never exist (loading from CSV uses the same checks).
    public Customer(String customerId, String name, String email) {
        this.customerId = Validation.requireNotBlank(customerId, "Customer ID");
        this.name = Validation.requireNotBlank(name, "Name");
        this.email = Validation.requireEmail(email);
    }

    public String getCustomerId() {
        return customerId;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    @Override
    public String toString() {
        return customerId + " | " + name + " | " + email;
    }
}
