package com.acme.hr.model;

public class Employee{
    private final int id;
    private String name;
    private String department;
    private double salary;

    private static int count=0;

    public Employee(int id,String name,String department,double salary){
        if(id<=0){
            throw new IllegalArgumentException("Invalid ID");
        }
        if(name==null||name.isBlank()){
            throw new IllegalArgumentException("Invalid name");
        }
        if(department==null||department.isBlank()){
            throw new IllegalArgumentException("Invalid department");
        }
        if(salary<0){
            throw new IllegalArgumentException("Invalid salary");
        }

        this.id=id;
        this.name=name;
        this.department=department;
        this.salary=salary;
        count++;
    }

    public int getId(){
        return id;
    }

    public String getName(){
        return name;
    }

    public String getDepartment(){
        return department;
    }

    public double getSalary(){
        return salary;
    }

    public static int getCreatedCount(){
        return count;
    }

    public void changeDepartment(String department){
        if(department==null||department.isBlank()){
            throw new IllegalArgumentException("Invalid department");
        }
        this.department=department;
    }

    public void updateSalary(double salary){
        if(salary<0){
            throw new IllegalArgumentException("Invalid salary");
        }
        this.salary=salary;
    }

    public void changeName(String name){
        if(name==null||name.isBlank()){
            throw new IllegalArgumentException("Invalid name");
        }
        this.name=name;
    }
}
