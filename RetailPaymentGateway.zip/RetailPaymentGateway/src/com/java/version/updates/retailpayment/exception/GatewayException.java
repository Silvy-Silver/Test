package com.java.version.updates.retailpayment.exception;

public class GatewayException extends Exception {
    public GatewayException(String message) {
        super(message);
    }
}
