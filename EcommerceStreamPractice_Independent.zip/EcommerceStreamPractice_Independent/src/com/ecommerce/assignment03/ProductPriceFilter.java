package com.ecommerce.assignment03;

import java.util.List;

public class ProductPriceFilter {
    public static void main(String[] args) {
        List<Product> products = List.of(
            new Product("Keyboard", 1500, true),
            new Product("Mouse", 700, true),
            new Product("Monitor", 12000, true),
            new Product("USB Hub", 1100, false),
            new Product("Headset", 1900, true)
        );

        System.out.println("In-stock products below ₹2,000:");
        products.stream()
            .filter(Product::isInStock)
            .filter(p -> p.getPrice() < 2000)
            .forEach(p -> System.out.printf("%s - ₹%.2f%n", p.getName(), p.getPrice()));

        long count = products.stream()
            .filter(Product::isInStock)
            .filter(p -> p.getPrice() < 2000)
            .count();

        System.out.println("Count: " + count);
    }
}
