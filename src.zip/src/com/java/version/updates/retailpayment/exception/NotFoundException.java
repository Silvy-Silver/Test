package com.java.version.updates.retailpayment.exception;

// A customer, order or transaction with the given ID does not exist.
public class NotFoundException extends GatewayException {

    private static final long serialVersionUID = 1L;

    public NotFoundException(String entity, String id) {
        super(entity + " not found: " + id);
    }
}
