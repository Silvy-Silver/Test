package com.ecommerce;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class EmployeeFilter {
    public static void main(String[] args) {
        List<Employee> emp=Arrays.asList(
            new Employee("Rahul",75000,true),
            new Employee("Akhil",50000,true),
            new Employee("Priya",90000,true),
            new Employee("Sneha",80000,false)
        );

        List<String> res=emp.stream()
            .filter(e -> e.isActive())
            .filter(e -> e.getSalary()>60000)
            .map(e -> e.getName())
            .sorted()
            .collect(Collectors.toList());

        System.out.println(res);
    }
}
