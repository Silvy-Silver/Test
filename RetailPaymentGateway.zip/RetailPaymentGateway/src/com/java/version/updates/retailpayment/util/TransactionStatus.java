package com.java.version.updates.retailpayment.util;

public enum TransactionStatus {
    PENDING,
    SUCCESS,
    FAILED,
    REFUNDED
}
