package com.ecommerce.assignment18;

import java.util.Comparator;
import java.util.List;

public class PriceRangeFilter {
    public static void main(String[] args) {
        List<Product> products = List.of(
            new Product("Mouse", 700, true),
            new Product("Keyboard", 1500, true),
            new Product("Webcam", 2800, true),
            new Product("SSD", 4500, true),
            new Product("Headset", 5000, true),
            new Product("Monitor", 12000, true),
            new Product("USB Cable", 500, false),
            new Product("Dock", 3800, false)
        );

        System.out.println("In-stock products from ₹500 to ₹5,000:");
        products.stream()
            .filter(Product::isInStock)
            .filter(p -> p.getPrice() >= 500 && p.getPrice() <= 5000)
            .sorted(Comparator.comparingDouble(Product::getPrice))
            .forEach(p -> System.out.printf("%s - ₹%.2f%n", p.getName(), p.getPrice()));

        System.out.println("Five cheapest matching products:");
        products.stream()
            .filter(Product::isInStock)
            .filter(p -> p.getPrice() >= 500 && p.getPrice() <= 5000)
            .sorted(Comparator.comparingDouble(Product::getPrice))
            .limit(5)
            .forEach(p -> System.out.printf("%s - ₹%.2f%n", p.getName(), p.getPrice()));
    }
}
