package com.ecommerce.assignment10;

import java.util.List;

public class ProductCategoryFilter {
    public static void main(String[] args) {
        List<Product> products = List.of(
            new Product("Laptop", "Electronics"),
            new Product("Phone", "Electronics"),
            new Product("T-shirt", "Clothing"),
            new Product("Jeans", "Clothing"),
            new Product("Coffee Maker", "Home"),
            new Product("Tablet", "Electronics")
        );

        List<String> categories = products.stream()
            .map(Product::getCategory)
            .distinct()
            .sorted()
            .toList();

        System.out.println("Distinct sorted categories: " + categories);
        System.out.println("Category count: " + categories.size());

        String selected = "Electronics";
        System.out.println("Products in " + selected + ":");
        products.stream()
            .filter(p -> p.getCategory().equalsIgnoreCase(selected))
            .map(Product::getName)
            .forEach(System.out::println);
    }
}
