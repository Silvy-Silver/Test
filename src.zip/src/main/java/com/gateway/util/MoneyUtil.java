package com.gateway.util;

import java.math.BigDecimal;
import java.math.RoundingMode;

/** The single place that decides how money is rounded and displayed. */
public final class MoneyUtil {

    private static final String CURRENCY_PREFIX = "Rs. ";
    private static final int SCALE = 2;

    private MoneyUtil() {
    }

    /** Rounds to 2 decimal places using HALF_UP. */
    public static BigDecimal scale(BigDecimal value) {
        return value.setScale(SCALE, RoundingMode.HALF_UP);
    }

    /** Formats as "Rs. 2500.00". */
    public static String format(BigDecimal value) {
        return CURRENCY_PREFIX + scale(value).toPlainString();
    }
}
