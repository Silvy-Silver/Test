package com.gateway.model;

import com.gateway.exception.RefundException;

import java.math.BigDecimal;
import java.time.LocalDateTime;

// One payment attempt. Status changes only through the methods below, so an invalid transition
// (for example refunding a failed payment) is impossible from outside the class.
public class Transaction implements Refundable {

    private final String transactionId;
    private final String orderId;
    private final String customerId;
    private final BigDecimal amount;
    private final BigDecimal gatewayFee;
    private final PaymentType paymentType;
    private final LocalDateTime createdAt;
    // These three change during the life of a transaction; all other fields are fixed once created.
    private TransactionStatus status;
    private LocalDateTime refundedAt;
    private String message;

    // Starts a new attempt in PENDING state.
    public Transaction(String transactionId, String orderId, String customerId, BigDecimal amount,
                       BigDecimal gatewayFee, PaymentType paymentType, LocalDateTime createdAt) {
        this(transactionId, orderId, customerId, amount, gatewayFee, paymentType, createdAt,
                TransactionStatus.PENDING, null, "");
    }

    private Transaction(String transactionId, String orderId, String customerId, BigDecimal amount,
                        BigDecimal gatewayFee, PaymentType paymentType, LocalDateTime createdAt,
                        TransactionStatus status, LocalDateTime refundedAt, String message) {
        this.transactionId = transactionId;
        this.orderId = orderId;
        this.customerId = customerId;
        this.amount = amount;
        this.gatewayFee = gatewayFee;
        this.paymentType = paymentType;
        this.createdAt = createdAt;
        this.status = status;
        this.refundedAt = refundedAt;
        this.message = message == null ? "" : message;
    }

    // Rebuilds a saved transaction exactly as it was stored (used when loading from CSV).
    public static Transaction restore(String transactionId, String orderId, String customerId, BigDecimal amount,
                                      BigDecimal gatewayFee, PaymentType paymentType, LocalDateTime createdAt,
                                      TransactionStatus status, LocalDateTime refundedAt, String message) {
        return new Transaction(transactionId, orderId, customerId, amount, gatewayFee, paymentType,
                createdAt, status, refundedAt, message);
    }

    // Allowed only from PENDING. Status changes happen only through the methods in this class.
    public void markSuccess(String message) {
        requirePending();
        this.status = TransactionStatus.SUCCESS;
        this.message = message;
    }

    // Allowed only from PENDING.
    public void markFailed(String message) {
        requirePending();
        this.status = TransactionStatus.FAILED;
        this.message = message;
    }

    // Only a SUCCESS transaction can be refunded.
    @Override
    public boolean isRefundable() {
        return status == TransactionStatus.SUCCESS;
    }

    // SUCCESS -> REFUNDED. Throws RefundException for a repeat refund or a non-successful payment.
    @Override
    public void refund(LocalDateTime refundedAt) {
        if (status == TransactionStatus.REFUNDED) {
            throw new RefundException("Transaction " + transactionId + " has already been refunded.");
        }
        if (!isRefundable()) {
            throw new RefundException("Only successful transactions can be refunded; "
                    + transactionId + " is " + status + ".");
        }
        this.status = TransactionStatus.REFUNDED;
        this.refundedAt = refundedAt;
        this.message = "Full refund completed";
    }

    // Guard: the final result (success/failed) can be set only once.
    private void requirePending() {
        if (status != TransactionStatus.PENDING) {
            throw new IllegalStateException("Transaction " + transactionId + " is already " + status + ".");
        }
    }

    // Amount the merchant receives: payment amount minus the gateway fee.
    public BigDecimal getNetAmount() {
        return amount.subtract(gatewayFee);
    }

    public String getTransactionId() {
        return transactionId;
    }

    public String getOrderId() {
        return orderId;
    }

    public String getCustomerId() {
        return customerId;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public BigDecimal getGatewayFee() {
        return gatewayFee;
    }

    public PaymentType getPaymentType() {
        return paymentType;
    }

    public TransactionStatus getStatus() {
        return status;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public LocalDateTime getRefundedAt() {
        return refundedAt;
    }

    public String getMessage() {
        return message;
    }
}
