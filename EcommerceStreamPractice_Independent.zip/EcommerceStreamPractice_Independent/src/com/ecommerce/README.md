# Ecommerce Stream Practice — Independent Assignments

This is one IntelliJ IDEA project containing six **independent** Java exercises.
Each assignment has its own package, model class(es), runner class, and sample data.
There are no shared model classes, shared data classes, or dependencies between assignments.

## Requirements
- Java 21
- IntelliJ IDEA

## Open in IntelliJ
1. Extract the ZIP.
2. In IntelliJ, choose **File → Open** and select the extracted `EcommerceStreamPractice_Independent` folder.
3. If IntelliJ asks for a JDK, select Java 21.
4. The source root is `src`. If IntelliJ does not mark it automatically, right-click `src` → **Mark Directory as → Sources Root**.
5. Open any runner class below and click the green run arrow beside `main`.

## Run each assignment
- `com.ecommerce.assignment03.ProductPriceFilter`
- `com.ecommerce.assignment10.ProductCategoryFilter`
- `com.ecommerce.assignment14.CustomerOrderItems`
- `com.ecommerce.assignment16.ProductAvailabilitySearch`
- `com.ecommerce.assignment18.PriceRangeFilter`
- `com.ecommerce.assignment19.CustomerOrderHistory`

## Where are the classes?
Every class is in its own `.java` file, as requested for IntelliJ. For example, Assignment 14 has `Product.java`, `OrderItem.java`, `Order.java`, and `CustomerOrderItems.java` in its own package.

## Concepts covered
- Assignment 03: `filter`, method references, `forEach`, `count`
- Assignment 10: `map`, `distinct`, `sorted`, `toList`, category filtering
- Assignment 14: `flatMap`, `map`, `distinct`, `groupingBy`, `counting`
- Assignment 16: `filter`, `findFirst`, `Optional`, `min`, `sorted`, `limit`
- Assignment 18: inclusive range filtering, `sorted`, `limit`
- Assignment 19: date sorting, `limit`, `BigDecimal`, `reduce`, `count`

All examples use local sample data only. No database, Spring Boot, Maven dependencies, or external libraries are required.
