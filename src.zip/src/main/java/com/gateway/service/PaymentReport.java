package com.gateway.service;

import com.gateway.model.TransactionStatus;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.EnumMap;
import java.util.Map;

/** Immutable snapshot of payment totals. Printing is the UI's job, not the service's. */
public final class PaymentReport {

    private final int totalAttempts;
    private final Map<TransactionStatus, Long> countByStatus;
    private final BigDecimal successfulGross;
    private final BigDecimal successfulFees;
    private final BigDecimal successfulNet;
    private final BigDecimal refundedTotal;

    public PaymentReport(int totalAttempts, Map<TransactionStatus, Long> countByStatus,
                         BigDecimal successfulGross, BigDecimal successfulFees,
                         BigDecimal successfulNet, BigDecimal refundedTotal) {
        this.totalAttempts = totalAttempts;
        this.countByStatus = Collections.unmodifiableMap(new EnumMap<TransactionStatus, Long>(countByStatus));
        this.successfulGross = successfulGross;
        this.successfulFees = successfulFees;
        this.successfulNet = successfulNet;
        this.refundedTotal = refundedTotal;
    }

    public int getTotalAttempts() {
        return totalAttempts;
    }

    public long getCount(TransactionStatus status) {
        return countByStatus.get(status);
    }

    public BigDecimal getSuccessfulGross() {
        return successfulGross;
    }

    public BigDecimal getSuccessfulFees() {
        return successfulFees;
    }

    public BigDecimal getSuccessfulNet() {
        return successfulNet;
    }

    public BigDecimal getRefundedTotal() {
        return refundedTotal;
    }
}
