package com.gateway.util;

import com.gateway.exception.ValidationException;

import java.math.BigDecimal;
import java.util.regex.Pattern;

/** Reusable input rules. Every model and service uses these instead of re-writing checks. */
public final class Validation {

    private static final Pattern EMAIL = Pattern.compile("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");

    private Validation() {
    }

    public static String requireNotBlank(String value, String fieldName) {
        if (value == null || value.trim().isEmpty()) {
            throw new ValidationException(fieldName + " is required.");
        }
        return value.trim();
    }

    public static String requireEmail(String value) {
        String email = requireNotBlank(value, "Email");
        if (!EMAIL.matcher(email).matches()) {
            throw new ValidationException("Please enter a valid email address.");
        }
        return email;
    }

    /** Amount must be present, greater than zero and have at most 2 decimal places. Returns it rounded to scale 2. */
    public static BigDecimal requirePositiveAmount(BigDecimal amount, String fieldName) {
        if (amount == null) {
            throw new ValidationException(fieldName + " is required.");
        }
        if (amount.signum() <= 0) {
            throw new ValidationException(fieldName + " must be greater than zero.");
        }
        if (amount.stripTrailingZeros().scale() > 2) {
            throw new ValidationException(fieldName + " can have at most 2 decimal places.");
        }
        return MoneyUtil.scale(amount);
    }
}
