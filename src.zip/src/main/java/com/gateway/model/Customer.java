package com.gateway.model;

import com.gateway.util.Validation;

public class Customer {

    private final String customerId;
    private final String name;
    private final String email;

    public Customer(String customerId, String name, String email) {
        this.customerId = Validation.requireNotBlank(customerId, "Customer ID");
        this.name = Validation.requireNotBlank(name, "Name");
        this.email = Validation.requireEmail(email);
    }

    public String getCustomerId() {
        return customerId;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    @Override
    public String toString() {
        return customerId + " | " + name + " | " + email;
    }
}
