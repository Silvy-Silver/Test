package com.java.version.updates.retailpayment.model;
import java.math.BigDecimal;
import java.math.RoundingMode;
public class Product {
    private final int displayNumber;
    private final String productId, name;
    private final BigDecimal price;
    public Product(int displayNumber, String productId, String name, BigDecimal price) {
        if (displayNumber <= 0 || productId == null || name == null || name.trim().isEmpty()
                || price == null || price.compareTo(BigDecimal.ZERO) <= 0)
            throw new IllegalArgumentException("Invalid product details.");
        this.displayNumber = displayNumber; this.productId = productId; this.name = name;
        this.price = price.setScale(2, RoundingMode.HALF_UP);
    }
    public int getDisplayNumber() { return displayNumber; }
    public String getProductId() { return productId; }
    public String getName() { return name; }
    public BigDecimal getPrice() { return price; }
}
