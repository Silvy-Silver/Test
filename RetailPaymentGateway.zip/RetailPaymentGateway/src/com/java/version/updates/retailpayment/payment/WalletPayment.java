package com.java.version.updates.retailpayment.payment;

import com.java.version.updates.retailpayment.model.PaymentResult;

import java.math.BigDecimal;

public class WalletPayment extends PaymentMethod {
    private final String walletId;

    public WalletPayment(String walletId) {
        this.walletId = walletId == null ? "" : walletId.trim();
    }

    @Override
    public boolean validatePayment(BigDecimal amount) {
        return amount != null && amount.compareTo(BigDecimal.ZERO) > 0
                && walletId.matches("[A-Za-z][A-Za-z0-9_-]{2,29}");
    }

    @Override
    public String getPaymentType() { return "WALLET"; }

    @Override
    public PaymentResult processPayment(BigDecimal amount) {
        if ("decline-demo".equalsIgnoreCase(walletId)) {
            return new PaymentResult(false, "Simulated wallet provider decline");
        }
        return new PaymentResult(true, "Simulated wallet payment approved");
    }
}
