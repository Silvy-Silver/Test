JAVA VERSION UPDATES - BEGINNER PRACTICE

Open this folder in IntelliJ IDEA, or open an individual exercise folder as a project.
Each exercise is independent and uses its own package.
Each class is in its own .java file.

Required JDK:
1. Exercise1_Java8_Streams - Java 8+
2. Exercise2_Java8_Optional - Java 8+
3. Exercise3_Java17_Record - Java 17+
4. Exercise4_SealedSwitch - Java 21 recommended (uses pattern matching switch)
5. Exercise5_Java21_VirtualThreads - Java 21+

IntelliJ notes:
- Set the Project SDK to the required JDK for the exercise.
- Source files are under src/com/ecommerce/.
- Run the class ending in Main, Filter, Search, or Demo as shown in each exercise.
- Exercise 4 uses Java 21 switch pattern matching, so use JDK 21.
- Exercise 5 uses virtual threads, introduced in Java 21.
