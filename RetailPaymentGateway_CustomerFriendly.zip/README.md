# Retail Payment Gateway — Customer-Friendly Core Java Mini Project

This console app simulates retail payments only. Never enter real card numbers, CVVs, UPI PINs, or banking credentials.

## Run in IntelliJ
1. Extract the ZIP and open `RetailPaymentGatewayCustomerFriendly`.
2. Configure JDK 8 or newer.
3. Mark `src` as Sources Root if needed.
4. Run `com.java.version.updates.retailpayment.app.Main`.

## Customer flow
- Register using your name and email. The app generates your customer ID.
- Browse products, choose products and quantities, and let the app calculate the total.
- View your orders and choose an unpaid order to pay.
- Use simulated UPI, card alias, or wallet details.
- View readable transaction history, transaction details, refunds, and reports.

Demo values only: `demo.user@upi`, `CARD-DEMO-1234`, `demo-wallet`.
Decline simulations: `decline-demo@upi`, `CARD-DEMO-DECLINE`, `decline-demo`.

Transactions persist in `data/transactions.csv`. Customer session and orders are in memory, so after restarting, register and create new orders again. Prior transaction history remains available.

The 1% gateway fee is an illustrative assignment rule, not an actual provider rate. No real provider is contacted.
