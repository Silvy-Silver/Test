package com.gateway.model;

import com.gateway.util.Validation;

import java.math.BigDecimal;

public class Product {

    private final String productId;
    private final String name;
    private final BigDecimal price;

    public Product(String productId, String name, BigDecimal price) {
        this.productId = Validation.requireNotBlank(productId, "Product ID");
        this.name = Validation.requireNotBlank(name, "Product name");
        this.price = Validation.requirePositiveAmount(price, "Product price");
    }

    public String getProductId() {
        return productId;
    }

    public String getName() {
        return name;
    }

    public BigDecimal getPrice() {
        return price;
    }
}
