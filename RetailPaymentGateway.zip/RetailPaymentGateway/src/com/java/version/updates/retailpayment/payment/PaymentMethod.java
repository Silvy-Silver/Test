package com.java.version.updates.retailpayment.payment;

import com.java.version.updates.retailpayment.model.PaymentResult;

import java.math.BigDecimal;

public abstract class PaymentMethod {
    public abstract boolean validatePayment(BigDecimal amount);
    public abstract String getPaymentType();
    public abstract PaymentResult processPayment(BigDecimal amount);
}
