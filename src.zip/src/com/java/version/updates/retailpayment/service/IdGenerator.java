package com.java.version.updates.retailpayment.service;

import java.util.Collection;
import java.util.concurrent.atomic.AtomicLong;

// Generates IDs such as CUS101, ORD101 and TXN1001.
// Each constant owns its own counter, so ID generation lives in one place instead of three static fields.
public enum IdGenerator {

    CUSTOMER("CUS", 101),
    ORDER("ORD", 101),
    TRANSACTION("TXN", 1001);

    private final String prefix;
    private final AtomicLong next;

    IdGenerator(String prefix, long firstNumber) {
        this.prefix = prefix;
        this.next = new AtomicLong(firstNumber);
    }

    public String next() {
        return prefix + next.getAndIncrement();
    }

    // Call after loading saved data so new IDs never collide with existing ones.
    public void advancePast(Collection<String> existingIds) {
        long highest = existingIds.stream()
                .filter(id -> id.startsWith(prefix))
                .map(id -> id.substring(prefix.length()))
                .filter(digits -> digits.matches("\\d+"))
                .mapToLong(Long::parseLong)
                .max()
                .orElse(0L);
        next.accumulateAndGet(highest + 1, Math::max);
    }
}
